"""Rebuild and report the bundled player predictor and Q-learning strategy."""
import json

from learning import LearningLab


if __name__ == "__main__":
    lab = LearningLab()
    artifact = lab.retrain()
    print(json.dumps({"supervised": artifact["supervised"] | {"model": "Multinomial Naive Bayes"}, "q_learning": artifact["q_learning"], "saved_to": "models/insider_learning.json"}, indent=2))
