/* THE INSIDER: agent profile, voice feedback, and walkable scene controls. */
(() => {
  const $ = (selector) => document.querySelector(selector);
  const login = $('#loginScreen');
  const gameRoot = $('#gameRoot');
  const profileInput = $('#agentName');
  const speechButton = $('#microphoneButton');
  const speechStatus = $('#voiceStatus');
  const recognitionApi = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let listening = false;
  let speechPrefix = '';
  let spokenWords = '';
  const voiceSettings = {
    ravi: { language: 'en-IN', style: 'male', rate: 0.94, pitch: 0.88, preferred: ['david', 'ravi', 'male'], voiceIndex: 0 },
    sarah: { language: 'en-IN', style: 'female', rate: 1.02, pitch: 1.12, preferred: ['zira', 'aria', 'jenny', 'female'], voiceIndex: 1 },
    mark: { language: 'en-GB', style: 'male', rate: 0.91, pitch: 0.76, preferred: ['george', 'ryan', 'male'], voiceIndex: 0 },
    alex: { language: 'en-US', style: 'male', rate: 1.04, pitch: 1.02, preferred: ['guy', 'alex', 'mark', 'david'], voiceIndex: 1 }
  };
  let muted = false;
  let volume = 0.8;

  function setupNpcVoice() {
    const owner = $('.dialogue-person');
    if (!owner) return;
    const controls = document.createElement('div');
    controls.className = 'npc-voice-controls';
    controls.innerHTML = '<button type="button" aria-label="Mute NPC voices" title="Mute NPC voices">VOICE ON</button><label><span>VOLUME</span><input type="range" min="0" max="1" step="0.05" value="0.8" aria-label="NPC voice volume"><output>80%</output></label>';
    owner.append(controls);
    const muteButton = controls.querySelector('button');
    const volumeInput = controls.querySelector('input');
    const output = controls.querySelector('output');
    muteButton.addEventListener('click', () => {
      muted = !muted;
      muteButton.textContent = muted ? 'VOICE OFF' : 'VOICE ON';
      muteButton.setAttribute('aria-label', muted ? 'Turn NPC voices on' : 'Mute NPC voices');
      muteButton.title = muteButton.getAttribute('aria-label');
      if (muted) window.speechSynthesis?.cancel();
    });
    volumeInput.addEventListener('input', () => {
      volume = Number(volumeInput.value);
      output.textContent = `${Math.round(volume * 100)}%`;
    });
    if (!('speechSynthesis' in window) || !window.SpeechSynthesisUtterance) {
      muteButton.disabled = true;
      volumeInput.disabled = true;
      muteButton.textContent = 'NO VOICE';
      muteButton.title = 'Spoken replies are not supported in this browser';
    }
  }

  function speakNpc(id, text) {
    if (muted || !text || !('speechSynthesis' in window) || !window.SpeechSynthesisUtterance) return;
    window.speechSynthesis.cancel();
    const settings = voiceSettings[id] || voiceSettings.ravi;
    const utterance = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    const exactLanguage = voices.filter((voice) => voice.lang.toLowerCase() === settings.language.toLowerCase());
    const matchingLanguage = exactLanguage.length ? exactLanguage : voices.filter((voice) => voice.lang.toLowerCase().startsWith(settings.language.slice(0, 2)));
    const matchingStyle = settings.preferred
      .map((name) => matchingLanguage.find((voice) => voice.name.toLowerCase().includes(name)))
      .find(Boolean);
    utterance.voice = matchingStyle || matchingLanguage[settings.voiceIndex % Math.max(matchingLanguage.length, 1)] || voices[0] || null;
    utterance.lang = settings.language;
    utterance.rate = settings.rate;
    utterance.pitch = settings.pitch;
    utterance.volume = volume;
    utterance.onstart = () => {
      if (typeof npcAct === 'function') npcAct('speaking');
    };
    utterance.onend = () => {
      if (typeof npcAct === 'function') npcAct('');
    };
    utterance.onerror = () => {
      if (typeof npcAct === 'function') npcAct('');
    };
    window.speechSynthesis.speak(utterance);
  }

  window.insiderVoice = {
    speak: speakNpc,
    stop: () => window.speechSynthesis?.cancel()
  };
  setupNpcVoice();

  function setProfile(name) {
    const cleanName = (name || 'INVESTIGATOR').trim().slice(0, 24).toUpperCase();
    $('#agentBadge').textContent = cleanName;
    $('.investigator-label').textContent = cleanName;
  }

  function enterField(name) {
    const cleanName = (name || '').trim();
    if (!cleanName) {
      profileInput.focus();
      return;
    }
    localStorage.setItem('insider_profile', cleanName);
    setProfile(cleanName);
    login.hidden = true;
    gameRoot.classList.remove('app-locked');
    if (!localStorage.getItem('insider_tutorial_seen') && !$('#tutorialDialog').open) {
      $('#tutorialDialog').showModal();
    }
    $('#gameScene').focus();
  }

  const savedProfile = localStorage.getItem('insider_profile');
  profileInput.value = savedProfile || '';
  if (savedProfile) {
    setProfile(savedProfile);
  }
  /* Always show the opening screen on a page load; a remembered codename is only prefilled. */
  login.hidden = false;
  gameRoot.classList.add('app-locked');
  $('#loginForm').addEventListener('submit', (event) => {
    event.preventDefault();
    enterField(profileInput.value);
  });
  $('#signOut').addEventListener('click', () => {
    const name = localStorage.getItem('insider_profile') || '';
    localStorage.removeItem('insider_profile');
    profileInput.value = name;
    login.hidden = false;
    gameRoot.classList.add('app-locked');
    profileInput.focus();
  });

  /* Replace the original listener so mic permission and browser limitations are explained. */
  const freshMicButton = speechButton.cloneNode(true);
  speechButton.replaceWith(freshMicButton);
  if (!recognitionApi) {
    freshMicButton.disabled = true;
    freshMicButton.title = 'Voice recognition is not supported in this browser';
    speechStatus.textContent = 'VOICE NOT SUPPORTED HERE · OPEN THIS GAME IN CHROME OR EDGE';
  } else {
    recognition = new recognitionApi();
    recognition.lang = 'en-IN';
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.onstart = () => {
      listening = true;
      freshMicButton.classList.add('recording');
      freshMicButton.setAttribute('aria-label', 'Stop voice input');
      freshMicButton.title = 'Listening… tap to stop';
      speechStatus.textContent = 'LISTENING · SPEAK CLEARLY, THEN PAUSE';
      if (typeof npcAct === 'function') npcAct('listening');
    };
    recognition.onresult = (event) => {
      let confirmed = '';
      let preview = '';
      for (let i = 0; i < event.results.length; i += 1) {
        const phrase = event.results[i][0].transcript;
        if (event.results[i].isFinal) confirmed += phrase;
        else preview += phrase;
      }
      spokenWords = (confirmed || preview).trim();
      const input = $('#messageInput');
      input.value = [speechPrefix, spokenWords].filter(Boolean).join(speechPrefix && spokenWords ? ' ' : '');
      input.dispatchEvent(new Event('input', { bubbles: true }));
      speechStatus.textContent = preview
        ? `HEARING · “${preview.toUpperCase()}”`
        : 'VOICE CAPTURED · REVIEW THE WORDS, THEN PRESS SEND';
    };
    recognition.onerror = (event) => {
      const messages = {
        'not-allowed': 'MIC BLOCKED · ALLOW THIS SITE IN BROWSER SETTINGS',
        'service-not-allowed': 'BROWSER BLOCKED SPEECH SERVICE · TRY CHROME OR EDGE',
        'no-speech': 'NO SPEECH HEARD · TAP THE MIC AND SPEAK AFTER THE TONE',
        network: 'SPEECH SERVICE NEEDS AN INTERNET CONNECTION',
        'audio-capture': 'NO MICROPHONE FOUND · CHECK YOUR DEVICE',
        aborted: 'VOICE INPUT STOPPED'
      };
      speechStatus.textContent = messages[event.error] || `VOICE ERROR · ${String(event.error).toUpperCase()}`;
    };
    recognition.onend = () => {
      listening = false;
      freshMicButton.classList.remove('recording');
      freshMicButton.setAttribute('aria-label', 'Start voice input');
      freshMicButton.title = 'Speak your question';
      if (/^LISTENING/.test(speechStatus.textContent)) {
        speechStatus.textContent = $('#messageInput').value
          ? 'VOICE CAPTURED · REVIEW THE WORDS, THEN PRESS SEND'
          : 'NO SPEECH CAPTURED · TAP THE MIC AND TRY AGAIN';
      }
    };
    freshMicButton.addEventListener('click', async () => {
      if (listening) {
        recognition.stop();
        return;
      }
      speechPrefix = $('#messageInput').value.trim();
      spokenWords = '';
      if (!window.isSecureContext) {
        speechStatus.textContent = 'MIC REQUIRES LOCALHOST OR HTTPS · OPEN http://localhost:8765';
        return;
      }
      speechStatus.textContent = 'REQUESTING MICROPHONE · CHOOSE ALLOW IN THE BROWSER';
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error('mic-unavailable');
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
        speechStatus.textContent = 'MIC READY · SPEAK AFTER THE LISTENING MESSAGE';
        recognition.start();
      } catch (error) {
        const messages = {
          'NotAllowedError': 'MIC BLOCKED · CLICK THE SITE ICON BY THE ADDRESS BAR AND ALLOW MICROPHONE',
          'PermissionDeniedError': 'MIC BLOCKED · CLICK THE SITE ICON BY THE ADDRESS BAR AND ALLOW MICROPHONE',
          'NotFoundError': 'NO MICROPHONE FOUND · CONNECT OR ENABLE A MICROPHONE',
          'NotReadableError': 'MIC IS BUSY · CLOSE OTHER APPS USING IT, THEN RETRY',
          'mic-unavailable': 'THIS BROWSER CANNOT OPEN THE MICROPHONE · TRY CHROME OR EDGE'
        };
        speechStatus.textContent = messages[error.name] || 'MIC NOT READY · CHECK BROWSER PERMISSIONS AND TRY AGAIN';
      }
    });
  }

  /* Walk the investigator around the floor using WASD or the arrow keys. */
  const investigator = $('#investigator');
  const scene = $('#sceneArt');
  const gameScene = $('#gameScene');
  const pressed = new Set();
  const position = { x: 26, y: 12 };
  let walkingFrame = 0;
  let previousFrame = 0;
  const clamp = (value, minimum, maximum) => Math.max(minimum, Math.min(maximum, value));
  function applyPosition() {
    investigator.style.left = `${position.x}%`;
    investigator.style.bottom = `${position.y}%`;
  }
  function stopWalking() {
    investigator.classList.remove('walking');
    previousFrame = 0;
    if (!pressed.size) $('#moveStatus').textContent = 'READY · WALK TO A PERSON OR CLUE';
  }
  function walkFrame(timestamp) {
    if (!pressed.size || gameRoot.classList.contains('app-locked')) {
      walkingFrame = 0;
      stopWalking();
      return;
    }
    const delta = previousFrame ? Math.min((timestamp - previousFrame) / 1000, 0.04) : 0.016;
    previousFrame = timestamp;
    const bounds = scene.getBoundingClientRect();
    const horizontal = Number(pressed.has('d') || pressed.has('arrowright')) - Number(pressed.has('a') || pressed.has('arrowleft'));
    const vertical = Number(pressed.has('w') || pressed.has('arrowup')) - Number(pressed.has('s') || pressed.has('arrowdown'));
    position.x = clamp(position.x + horizontal * 175 * delta / bounds.width * 100, 4, 91);
    position.y = clamp(position.y + vertical * 150 * delta / bounds.height * 100, 9, 40);
    applyPosition();
    walkingFrame = requestAnimationFrame(walkFrame);
  }
  function walkTo(x, y, callback, duration = 600) {
    pressed.clear();
    if (walkingFrame) cancelAnimationFrame(walkingFrame);
    walkingFrame = 0;
    investigator.classList.remove('walking');
    investigator.classList.add('scene-walk', 'walking');
    position.x = clamp(x, 4, 91);
    position.y = clamp(y, 9, 40);
    applyPosition();
    $('#moveStatus').textContent = 'WALKING…';
    window.setTimeout(() => {
      investigator.classList.remove('scene-walk', 'walking');
      $('#moveStatus').textContent = 'READY · WALK TO A PERSON OR CLUE';
      if (callback) callback();
    }, duration);
  }
  document.addEventListener('keydown', (event) => {
    if (gameRoot.classList.contains('app-locked') || document.querySelector('dialog[open]')) return;
    if (event.target.closest('input, textarea, select, [contenteditable="true"]')) return;
    const key = event.key.toLowerCase();
    if (['w', 'a', 's', 'd', 'arrowup', 'arrowleft', 'arrowdown', 'arrowright'].includes(key)) {
      event.preventDefault();
      pressed.add(key);
      investigator.classList.add('walking');
      $('#moveStatus').textContent = 'WALKING · RELEASE TO STOP';
      if (!walkingFrame) walkingFrame = requestAnimationFrame(walkFrame);
    } else if (key === 'e') {
      event.preventDefault();
      interactNearby();
    }
  });
  document.addEventListener('keyup', (event) => {
    pressed.delete(event.key.toLowerCase());
    if (!pressed.size) stopWalking();
  });
  window.addEventListener('blur', () => {
    pressed.clear();
    stopWalking();
  });
  gameScene.tabIndex = 0;
  gameScene.addEventListener('pointerdown', (event) => {
    if (event.target.closest('button, input, textarea')) return;
    gameScene.focus();
    $('#moveStatus').textContent = 'READY · WASD / ARROWS TO WALK · E TO INTERACT';
  });
  applyPosition();

  const npcSprite = $('#npcSprite');
  const npcPatrols = {
    ravi: [22, 17, 24, 20],
    sarah: [25, 20, 17, 23],
    mark: [18, 23, 19, 26],
    alex: [24, 18, 26, 21]
  };
  let patrolStep = 0;
  window.setInterval(() => {
    if (!npcSprite || gameRoot.classList.contains('app-locked') ||
        currentLocation !== 'Interview Room' || document.querySelector('dialog[open]') ||
        $('.typing') || npcSprite.classList.contains('listening') ||
        npcSprite.classList.contains('speaking')) return;
    const patrol = npcPatrols[active] || npcPatrols.ravi;
    npcSprite.classList.add('npc-patrol-walking');
    npcSprite.style.right = `${patrol[patrolStep % patrol.length]}%`;
    patrolStep += 1;
    window.setTimeout(() => npcSprite.classList.remove('npc-patrol-walking'), 1900);
  }, 6200);

  function playerFoot() {
    const box = gameScene.getBoundingClientRect();
    return {
      x: box.left + (position.x / 100) * box.width + investigator.offsetWidth / 2,
      y: box.bottom - (position.y / 100) * box.height - 9
    };
  }
  function targetDistance(element) {
    const point = playerFoot();
    const target = element.getBoundingClientRect();
    const dx = point.x - (target.left + target.width / 2);
    const dy = point.y - (target.top + target.height / 2);
    return Math.hypot(dx, dy);
  }
  function pointBeside(element) {
    const stage = scene.getBoundingClientRect();
    const target = element.getBoundingClientRect();
    return {
      x: ((target.left + target.width / 2 - stage.left) / stage.width) * 100 - 2.5,
      y: ((stage.bottom - target.bottom + 16) / stage.height) * 100
    };
  }
  function walkToTalk() {
    if (currentLocation !== 'Interview Room') {
      toast('Return to the Interview Room to question the team.');
      return;
    }
    walkTo(70, 14, () => {
      $('#contextText').textContent = `${npcInfo[active].name} is ready for your question.`;
      $('#messageInput').focus();
    }, 540);
  }
  function updateExit() {
    const exits = game?.state?.unlocked_locations?.filter((location) => location !== currentLocation) || [];
    const next = exits[0];
    $('#exitDestination').textContent = next ? `TO ${next.toUpperCase()}` : 'NO EXIT YET';
  }
  if (typeof render === 'function') {
    const originalRender = render;
    render = function (...args) {
      const result = originalRender.apply(this, args);
      updateExit();
      return result;
    };
  }
  $('#roomExit').addEventListener('click', () => {
    const next = game?.state?.unlocked_locations?.find((location) => location !== currentLocation);
    if (!next) {
      toast('No other room is open yet. Keep investigating to find an access clue.');
      return;
    }
    document.querySelector(`.location[data-location="${next}"]`)?.click();
  });
  function interactNearby() {
    const targets = [];
    if (currentLocation === 'Interview Room') targets.push({ element: $('#npcSprite'), type: 'npc' });
    document.querySelectorAll('.hotspot:not([hidden])').forEach((element) => targets.push({ element, type: 'clue' }));
    const nearest = targets.map((target) => ({ ...target, distance: targetDistance(target.element) }))
      .sort((a, b) => a.distance - b.distance)[0];
    if (nearest && nearest.distance < 150) {
      if (nearest.type === 'npc') walkToTalk();
      else examine(nearest.element.dataset.object);
    } else {
      toast('Walk closer to a highlighted person or clue, then press E.');
    }
  }
  $('#talkToNpc').addEventListener('click', (event) => {
    event.preventDefault();
    event.stopImmediatePropagation();
    walkToTalk();
  }, true);
  $('#npcSprite').addEventListener('click', walkToTalk);
  document.querySelectorAll('.hotspot').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      const destination = pointBeside(button);
      walkTo(destination.x, destination.y, () => examine(button.dataset.object));
    }, true);
  });
  document.querySelectorAll('.location').forEach((button) => {
    button.addEventListener('click', async (event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      const location = button.dataset.location;
      if (busy || location === currentLocation) return;
      if (!game?.state?.unlocked_locations?.includes(location)) {
        toast('That area is locked. Find the required evidence first.');
        return;
      }
      const oldPosition = { ...position };
      busy = true;
      document.querySelectorAll('.location').forEach((item) => { item.disabled = true; });
      walkTo(89, 12, async () => {
        try {
          const result = await call('/move', { session_id: game.session_id, location });
          game.state = result.state;
          position.x = 24;
          position.y = 13;
          render();
          applyPosition();
          sys(`ARRIVED · ${location.toUpperCase()} · WASD/ARROWS TO EXPLORE`);
        } catch (error) {
          position.x = oldPosition.x;
          position.y = oldPosition.y;
          applyPosition();
          toast(error.message);
        } finally {
          busy = false;
          document.querySelectorAll('.location').forEach((item) => { item.disabled = false; });
        }
      }, 560);
    }, true);
  });
})();
