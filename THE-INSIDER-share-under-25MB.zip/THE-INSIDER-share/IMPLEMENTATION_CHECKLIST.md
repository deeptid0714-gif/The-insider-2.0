# THE INSIDER · implementation checklist

## AI learning upgrade

- [x] Added a dependency-free multinomial Naive Bayes player-action model trained on 3,200 simulated play episodes; episodes, not individual rows, are split 80/20 to hold out test data.
- [x] Measured held-out accuracy and compared it with the most-frequent-label baseline. Current bundled artifact: 50.73% versus 20.27% on 4,824 held-out decisions.
- [x] Added a tabular Q-learning suspect strategy with explicit state (player style, case stage, trust band, and tone), valid tactic actions, rewards, transitions, and 18,000 training episodes.
- [x] Evaluated the learned Q policy on 1,200 separate simulated states against the fixed `hold boundary` policy. Current bundled mean reward: 2.488 versus 0.067.
- [x] The trained Q policy chooses dialogue tactics during actual interviews; tactics may change how a suspect asks for evidence or maintains a boundary, but cannot change case facts or award evidence.
- [x] Added the AI Lab panel with training metrics, held-out and baseline comparisons, reward progression, real runtime counts, live scored predictions, and completed investigation outcomes.
- [x] Added counterfactual accusation replay using the same deterministic evaluator on a deep copy; it cannot mutate the actual case.
- [x] Kept local text input available and centralized speech recognition in the permission-aware `controls.js` implementation so the browser creates only one recognition instance.
- [ ] An actual microphone/hardware capture still depends on a supported browser, an allowed microphone, and its speech service; automated checks cannot grant that permission or validate the user's microphone.

### Verification for this upgrade

- [x] `python -m py_compile main.py learning.py`
- [x] `python -m pytest -q tests/test_learning.py` — 5 passed.
- [x] `python -m unittest discover -s tests -p test_engine_unittest.py -v` — 18 passed.
- [ ] Full FastAPI TestClient suite could not complete in the restricted shell: this environment blocks the local socketpair needed by AnyIO/TestClient. Run it in a normal local Python terminal with `python -m pytest -q tests`.

## Prompt audit

- Inspected the FastAPI routes, dialogue engine, frontend request flow, saved session state, scene hotspots, accusation flow, and tests before making this pass.
- Confirmed the supplied prompt ends mid-sentence after “Each” in section 5.2. Requirements beyond that text could not be audited.
- Existing case persistence and the noir presentation were retained.

## Stage 1 · conversation

- [x] Optional server-side structured intent classification; deterministic offline fallback is labeled.
- [x] NPC-specific intent filtering, follow-up context, ambiguity/irrelevance handling, bounded multi-part answers, and contradiction challenges.
- [x] Model output is schema-validated; evidence presentation is independently verified from the player's message; only deterministic rules award clues.
- [x] NPC-specific boundaries, repeat handling, direct/indirect phrasing, and failure fallback are covered in tests.

## Stage 2 · game state

- [x] Evidence records include source, facts, allowed reveal sources, prerequisites, related records, contradiction notes, and discovery metadata.
- [x] Claims, player observations, verified records/facts, and conclusions are separate in game state and the case board.
- [x] Trust changes are bounded and logged with their cause; trust does not replace evidence prerequisites.
- [x] Interview Room, Server Floor, and Records Archive have location-gated actions and state-derived objectives.
- [x] Accusations distinguish insufficient, wrong, correct-but-weak, and solved outcomes; solved requires selected evidence and an explained theory.

## Stage 3 · NPC memory and behavior

- [x] NPC profiles separate known facts, beliefs, mistaken beliefs, secrets, withholding, disclosures, evidence shown, trust, and attitude.
- [x] Significant conversation, evidence presentation, contradictions, threats, promises, and disclosure events are persisted and bounded.
- [x] Responses use NPC-specific knowledge and evidence shown; memory survives refresh through local session persistence.
- [x] NPC sprite has idle, listening, speaking, and defensive/open reaction states; investigator moves between rooms.

## Verification

- [x] `python -m compileall -q main.py`
- [x] `.venv312\\Scripts\\python.exe -m pytest -q` — 60 passed.
- [x] `.venv312\\Scripts\\python.exe -m unittest discover -s tests -p test_engine_unittest.py -v` — 18 passed.
- [x] Share package excludes local `.env`, case session data, virtual environments, and caches.

## Second investigation

- [x] Case 047 unlocks Case 048 only after a supported solved ending.
- [x] Case 048, “The Missing Minutes,” is a different incident with its own evidence catalog, scene gates, witness disclosures, memory, objectives, accusation criteria, and saved session.
- [x] Wrong/weak/insufficient/solved outcomes remain available in Case 048.
- The supplied prompt ends mid-sentence after “Each” in section 5.2; requirements beyond that text could not be audited.

## Playability improvements

- [x] Added an in-game noir sign-in/start screen with a local investigator codename and saved-case notice. It is a local profile label, not an online authentication service.
- [x] Added walkable scene movement with WASD/arrow keys, visible movement instructions, proximity interaction with E, click-to-walk for people and clues, and an exit transition into unlocked rooms.
- [x] Expanded the field briefing with the investigation loop, room unlocks, evidence board, voice control, and accusation steps.
- [x] Improved microphone permission preflight and explicit browser support, no-speech, permission, device, and network messages.
- [ ] Voice recognition still relies on the browser Web Speech API; embedded browsers may not expose it. Open the localhost game in current Chrome or Edge and allow microphone access. Typing remains available when speech service is unavailable.


## Behavioral Read iteration

- [x] Added a per-interview behavioral read with an explicit cue, likely response, recommended next move, and heuristic confidence.
- [x] The read uses the current case's trust, dialogue tone, NPC attitude, and evidence already shown; it is returned by both case interview flows.
- [x] Added the read to the dialogue UI and labeled its basis and limitation clearly.
- [ ] Automatic webcam-based posture recognition is not implemented. The current read is a transparent gameplay heuristic, not actual body-language sensing or a psychological diagnosis.
- [x] Verification after this change: Python compilation passed, frontend JavaScript syntax checks passed, and `python -m pytest -q tests` passed (68 tests, 2 subtests).
