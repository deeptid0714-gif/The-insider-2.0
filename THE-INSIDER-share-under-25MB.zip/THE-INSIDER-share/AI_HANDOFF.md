# Continue building THE INSIDER

This bundle contains the current source for **THE INSIDER**, a playable 2D noir investigation game. Continue developing this game; do not replace it with an unrelated product or a static landing page.

## Start here

1. Read `README.md`, `DEMO_SCRIPT.md`, and `IMPLEMENTATION_CHECKLIST.md`.
2. Inspect `main.py` and the files under `static/` before changing behavior.
3. Preserve the game's established case facts, evidence gates, NPC knowledge boundaries, and refresh behavior unless the user explicitly asks to change them.
4. Make improvements directly in the existing project and explain the changed files and how to run the result.

## Current game

- FastAPI backend with deterministic offline dialogue, with optional server-side OpenAI intent classification.
- Two linked investigations: Case 047 and the unlocked Case 048.
- Illustrated walkable rooms, NPC interviews, keyboard/click movement, evidence collection, trust and memory systems, room gates, and evaluated accusations.
- The opening screen asks for a local investigator codename. The codename stays prefilled in the same browser. Refreshing returns to the opening screen and starts a fresh copy of the current case.
- Voice input uses browser speech recognition when supported; text input remains available.
- A supervised Naive Bayes player-action predictor is trained and evaluated on held-out simulated episodes.
- A trained tabular Q-learning policy selects fair suspect dialogue tactics; it cannot change evidence or canonical facts.
- The AI Lab exposes actual training/test/baseline metrics and runtime/case counters.
- Counterfactual accusation replay runs a separate rule-based branch on a copied state without changing the actual case.

## Run locally

From this directory on Windows:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
uvicorn main:app --reload
```

Then open `http://localhost:8000/`. OpenAI is optional; the game runs offline without an API key.

## Architecture

- `main.py`: game state, case facts, API routes, dialogue, evidence rules, NPC memory, room progression, accusation outcomes.
- `learning.py` and `models/insider_learning.json`: supervised predictor, Q-learning opponent policy, training metrics, and saved policy.
- `static/index.html`: game start screen, scene, UI panels, dialogs.
- `static/app.js`: game rendering, server requests, dialogue, evidence and accusation flow.
- `static/controls.js`: local profile, speech input, walking, proximity interaction, room transitions.
- `static/style.css`: noir art direction, responsive interface, scene and character styling.
- `tests/`: backend and game-rule checks.

When adding features, keep changes inside this existing game, make sure backend state remains authoritative for facts and outcomes, and update the README/demo script if the player experience changes.
