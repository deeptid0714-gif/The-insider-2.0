# THE INSIDER · 3–5 minute demo

Run `uvicorn main:app --reload`, open `http://localhost:8000`, enter an investigator codename, then leave `OPENAI_API_KEY` empty to prove the offline route. The first briefing covers movement and interaction. Start a fresh case before presenting. The footer should say **OFFLINE DEMO · DETERMINISTIC INTENT**.

## Main route

**0:00 — Brief the judges**

“This is a playable 2D investigation game. The player signs into a local agent profile, walks the office with WASD, questions people in natural language, and uses evidence to change what they will say. The case engine—not a text generator—owns the facts and endings.”

**0:30 — Interview and withhold**

Select **Sarah Chen** and ask: `You are lying. What did you see near the server room?`

Expected: she becomes defensive, trust decreases by 8, and she says she needs corroboration. The evidence bag does not gain Sarah's statement. This demonstrates an actual evidence gate. The **Behavioral Read** panel should also report a defensive/closed stance heuristic, predict a denial or request for proof, and recommend de-escalating or presenting one verified record. Explain that the cue is derived from in-game trust and dialogue state, not webcam analysis.

**1:00 — Use a different phrasing and earn trust**

Select Alex and ask: `What does the badge reader show?` Then return to Sarah and ask: `The badge record shows Ravi was there. What did you see near the server room?`

Expected: the badge clue is explicitly presented to Sarah and is valid corroboration. She reveals her testimony even though trust is low, and says she saw Ravi with a metal USB but does not claim to know what was on it. Without corroboration, respectful questions raise trust by 4 each; she opens up at 52 if asked a relevant question without hostility.

**1:40 — Verify an independent record**

Select **Alex Rivera** and ask: `What does the badge reader show?`

Expected: badge record is added, confirming Ravi's corridor entry at 10:42, and **Server Floor** unlocks. Ask Alex: `Please tell me about the camera override.`

Expected: the camera note is added with the respectful approach, confirming the 10:39 loop came from Mark's office. This conversation shows Alex's security knowledge boundary: he cannot explain Ravi's motive.

**2:20 — Walk and inspect**

Walk toward the marked exit and press **E** near a person or clue. Use the room buttons to go to **SERVER FLOOR**, then examine **SERVER TERMINAL**.

Expected: the player sprite walks to the new scene; the terminal yields the deleted audit-row clue. The objective updates from finding access to verifying the audit.

Sarah's testimony plus the camera note now unlock **RECORDS ARCHIVE**. Travel there and inspect **APPROVAL LEDGER** to add Mark's export authorization.

If demonstrating voice input, use a browser that supports the Web Speech API, click the mic, allow microphone access, say a question, review its transcript, and press send. The browser must be able to reach its speech service; otherwise use typing and explain the visible voice error message.

**2:50 — Present evidence and test memory**

Return to **Ravi** and ask: `The badge record shows Ravi at 10:42. Sarah saw you with a USB. Why did you copy it?`

Expected: Ravi recognizes the two pieces of evidence because they were explicitly shown to him. He admits copying the file to preserve proof of Mark's planned sale and says he deleted the audit row in a panic. His confession becomes evidence. Ask him the same question again: he recalls the repeated question, but still responds with the case context rather than granting duplicate evidence.

**3:30 — Distinguish culprit from motive**

Select **Mark** and ask: `Why were you pushing the employee-data export?`

Expected: Mark admits authorizing an unauthorized commercial export. He can reveal his own motive, but cannot reveal Ravi's private reason. Ask Mark about the camera override after showing him the camera clue; he responds defensively.

**4:00 — Make a grounded accusation**

Click **MAKE YOUR ACCUSATION**, choose Ravi, and check **Badge record**, **Witness statement**, and **Why Ravi copied it**. Submit.

Expected: **CASE SOLVED · THE INSIDER**. The result explains that Ravi copied the file to preserve evidence while Mark planned the sale. The selected evidence appears in the result.

## Alternate route (about one minute)

Start a second case. Ask Alex about the badge record, then immediately choose **Make your accusation**. Expected: the case stays open as **Insufficient evidence**; the player is told to obtain Sarah's independent corroboration. In a separate fresh case, get the badge and witness statement, accuse **Mark**, and cite both: expected **Wrong accusation**. Or choose Ravi but cite only the badge record: expected **Right suspect · Weak case**.

## Judge mapping

- **Stage 1:** open-ended questions; two distinct badge phrasings work offline; vague questions get clarification; optional OpenAI structured intent mode is clearly labeled.
- **Stage 2:** dialogue changes trust and clues; clues unlock movement and hotspots; the ending evaluates selected discovered evidence.
- **Stage 3:** Sarah withholds testimony until trust/corroboration; the player presents evidence to Ravi and Mark; they remember it and respond according to their knowledge and personality; session memory survives refresh/restart.


## Unlock the second investigation

After the supported Case 047 accusation resolves, choose **UNLOCK CASE 048 · THE MISSING MINUTES**. This starts a new saved case and a different incident: the boardroom recording was erased before a complaint review.

1. Ask Alex: `Who entered the boardroom?` The access record shows Mark at 9:12 PM.
2. Ask Sarah: `The badge record shows Mark entered. What did you hear at the meeting?` She gives her statement only after corroboration.
3. Ask Alex: `Please tell me about the recorder trace.` Travel to **Server Floor** and inspect the recovery terminal. The trace unlocks **Records Archive**; inspect its request log.
4. Return to the Interview Room. Show Mark the removal request and ask why he erased the recording. His admission is new evidence.
5. Accuse Mark, cite the access record, Sarah's account, request log, and admission; explain that he ordered the erasure to suppress the complaint evidence. The second case resolves only when both evidence and theory support it.
