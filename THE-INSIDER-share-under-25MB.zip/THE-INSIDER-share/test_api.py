from google import genai

client = genai.Client(api_key="AQ.Ab8RN6JYS3M_gkPG9E30pc8Mm42wb97p0_bRFfOa8d3HX-Wi9g")

response = client.models.generate_content(
    model="gemini-3.8-flash",
    contents="Say hello and confirm you are working!",
)

print(response.text)