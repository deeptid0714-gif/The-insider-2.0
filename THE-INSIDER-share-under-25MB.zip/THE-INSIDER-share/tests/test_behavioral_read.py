import main


def test_hostile_or_low_trust_read_recommends_deescalation():
    state = main.fresh_state("047")
    state["trust"]["sarah"] = 28
    state["memory"]["sarah"]["emotional_state"] = "defensive"

    result = main.behavioral_read(state, "sarah", "hostile")

    assert "guarded" in result["cue"].lower()
    assert "proof" in result["likely_response"].lower()
    assert "stay calm" in result["recommended_next_move"].lower()


def test_presented_evidence_changes_behavioral_read():
    state = main.fresh_state("047")
    state["memory"]["ravi"]["presented_evidence"] = ["badge_record"]

    result = main.behavioral_read(state, "ravi", "neutral")

    assert "seen your clue" in result["cue"].lower()
    assert "clue" in result["likely_response"].lower()


def test_high_trust_read_predicts_more_cooperative_response():
    state = main.fresh_state("047")
    state["trust"]["alex"] = 75
    state["memory"]["alex"]["emotional_state"] = "open"

    result = main.behavioral_read(state, "alex", "respectful")

    assert "ready to talk" in result["cue"].lower()
    assert 0 < result["confidence"] < 1
