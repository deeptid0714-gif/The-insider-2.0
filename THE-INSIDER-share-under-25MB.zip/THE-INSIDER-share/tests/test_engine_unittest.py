"""Dependency-light checks of the deterministic game rules."""
import json
import os
import shutil
import unittest
import uuid
import main


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.folder = os.path.join(os.path.dirname(__file__), ".test-state-" + str(uuid.uuid4()))
        os.makedirs(self.folder)
        main.STATE_FILE = os.path.join(self.folder, "sessions.json")
        self.s = main.fresh_state()

    def tearDown(self):
        shutil.rmtree(self.folder, ignore_errors=True)

    def response(self, npc, text):
        intent = main.fallback_intent(text, npc, self.s["evidence"])
        mem = self.s["memory"][npc]
        shown_now = main.presented(self.s, npc, intent.references)
        shown = list(mem["presented_evidence"])
        delta, _ = main.trust_delta(intent, main.normalize(text) in [main.normalize(x) for x in mem["questions"]])
        self.s["trust"][npc] = max(0, min(100, self.s["trust"][npc] + delta))
        answer, new, _ = main.make_answer(npc, intent, self.s, text, shown, False)
        mem["questions"].append(text)
        return {"intent": intent, "answer": answer, "new": new, "shown": shown_now, "delta": delta}

    def test_case_begins_with_only_briefing_evidence(self):
        self.assertEqual(self.s["evidence"], ["server_log"])
        self.assertEqual(main.unlocked_locations(self.s), ["Interview Room"])

    def test_sarah_withholding_never_awards_witness_clue(self):
        result = self.response("sarah", "You are lying. What did you see near the server room?")
        self.assertNotIn("sarah_witness", self.s["evidence"])
        self.assertEqual(result["new"], [])

    def test_sarah_trust_threshold_unlocks_witness(self):
        self.s["trust"]["sarah"] = 52
        result = self.response("sarah", "Please tell me what you saw near the server room.")
        self.assertIn("sarah_witness", self.s["evidence"])

    def test_sarah_corroboration_also_unlocks_witness(self):
        main.add_clue(self.s, "badge_record", "alex")
        result = self.response("sarah", "The badge record shows Ravi was there. What did you see near the server room?")
        self.assertIn("sarah_witness", self.s["evidence"])

    def test_mark_cannot_reveal_ravi_private_motive(self):
        result = self.response("mark", "Why did Ravi copy the file?")
        self.assertNotIn("ravi_motive", self.s["evidence"])
        self.assertIn("private reasons", result["answer"])

    def test_badge_question_does_not_award_camera_clue(self):
        result = self.response("alex", "What does the badge reader show?")
        self.assertIn("badge_record", self.s["evidence"])
        self.assertNotIn("camera_loop", self.s["evidence"])

    def test_camera_clue_requires_respect_or_trust(self):
        result = self.response("alex", "What happened with the camera footage?")
        self.assertNotIn("camera_loop", self.s["evidence"])
        result = self.response("alex", "Please tell me about the camera override.")
        self.assertIn("camera_loop", self.s["evidence"])

    def test_rephrased_natural_language_maps_to_badge_intent(self):
        for text in ("Could you check the keycard entry?", "What does the badge reader show?"):
            with self.subTest(text=text):
                self.assertEqual(main.fallback_intent(text, "alex", ["server_log"]).intent, "badge_record")

    def test_ravi_motive_requires_both_clues_to_be_presented(self):
        main.add_clue(self.s, "badge_record", "alex")
        main.add_clue(self.s, "sarah_witness", "sarah")
        early = self.response("ravi", "Why did you copy the file?")
        self.assertNotIn("ravi_motive", self.s["evidence"])
        self.response("ravi", "The badge record shows Ravi at 10:42; Sarah saw you with a USB. Why did you copy it?")
        self.assertIn("ravi_motive", self.s["evidence"])

    def test_alex_cannot_speak_to_private_motive(self):
        result = self.response("alex", "Why did Ravi copy the employee file?")
        self.assertIn("why Ravi copied it", result["answer"])

    def test_presented_evidence_is_remembered(self):
        main.add_clue(self.s, "badge_record", "alex")
        main.add_clue(self.s, "sarah_witness", "sarah")
        self.response("ravi", "The badge record shows Ravi at 10:42; Sarah saw you with a USB. Why did you copy it?")
        later = self.response("ravi", "Why did you copy the file?")
        self.assertIn("All right. I copied it", later["answer"])

    def test_evidence_duplicate_is_rejected(self):
        self.assertTrue(main.add_clue(self.s, "badge_record", "alex"))
        self.assertFalse(main.add_clue(self.s, "badge_record", "alex"))

    def test_prerequisite_and_source_are_enforced(self):
        self.assertFalse(main.add_clue(self.s, "deleted_record", "server_terminal"))
        self.assertFalse(main.add_clue(self.s, "badge_record", "sarah"))

    def test_unlocks_and_objectives_follow_actual_state(self):
        main.add_clue(self.s, "badge_record", "alex")
        self.assertIn("Server Floor", main.unlocked_locations(self.s))
        main.add_clue(self.s, "deleted_record", "server_terminal")
        self.assertTrue(main.objective_state(self.s)["access_verified"])

    def test_trust_changes_are_bounded_and_caused_by_behavior(self):
        hostile, cause = main.trust_delta(main.Intent(intent="witness", tone="hostile", references=[]), False)
        polite, _ = main.trust_delta(main.Intent(intent="witness", tone="respectful", references=[]), False)
        self.assertEqual((hostile, cause), (-8, "hostile approach"))
        self.assertEqual(polite, 4)
        self.assertEqual(max(0, 2 + hostile), 0)
        self.assertEqual(min(100, 99 + polite), 100)

    def test_accusation_requires_badge_and_witness_and_cites_evidence(self):
        self.s["evidence"] += ["badge_record", "sarah_witness"]
        self.assertEqual(main.reason_references("badge at 10:42 and Sarah's USB witness", self.s["evidence"]), {"badge_record", "sarah_witness"})
        support = {"badge_record", "sarah_witness"}
        self.assertTrue({"badge_record", "sarah_witness"}.issubset(support))

    def test_atomic_memory_persistence_roundtrip(self):
        self.s["memory"]["ravi"]["questions"].append("Where were you?")
        main.SESSIONS.clear(); main.SESSIONS["case"] = self.s; main.persist()
        main.SESSIONS.clear(); main.load_sessions()
        self.assertEqual(main.SESSIONS["case"]["memory"]["ravi"]["questions"], ["Where were you?"])

    def test_older_or_malformed_state_is_migrated_safely(self):
        migrated=main.migrate_state({"evidence":["badge_record","unknown",[]],"trust":{"ravi":"bad","sarah":500},"location":"Records Archive","memory":{"ravi":{"questions":"bad"}},"turns":"bad"})
        self.assertEqual(migrated["evidence"],["server_log","badge_record"])
        self.assertEqual(migrated["trust"]["ravi"],48)
        self.assertEqual(migrated["trust"]["sarah"],100)
        self.assertEqual(migrated["location"],"Interview Room")
        self.assertEqual(migrated["memory"]["ravi"]["questions"],[])


if __name__ == "__main__":
    unittest.main()
