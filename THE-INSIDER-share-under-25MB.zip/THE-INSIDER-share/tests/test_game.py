import os
import shutil
import sys
import types
import uuid
import asyncio

import pytest
from fastapi.testclient import TestClient

import main


@pytest.fixture
def client(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GEMINI_MODEL", raising=False)
    folder = os.path.join(os.path.dirname(__file__), ".pytest-state-" + str(uuid.uuid4()))
    os.makedirs(folder)
    monkeypatch.setattr(main, "STATE_FILE", os.path.join(folder, "sessions.json"))
    main.SESSIONS.clear()
    try:
        with TestClient(main.app) as test_client:
            yield test_client
    finally:
        main.SESSIONS.clear()
        shutil.rmtree(folder, ignore_errors=True)


def start(client):
    result = client.post("/api/game", json={}).json()
    return result["session_id"], result["state"]


def talk(client, sid, npc, text):
    return client.post("/api/talk", json={"session_id": sid, "npc_id": npc, "message": text})


def ids(response):
    payload = response if isinstance(response, dict) else response.json()
    return {x["id"] for x in payload["state"]["evidence"]}


def test_new_case_starts_with_briefing_only(client):
    _, state = start(client)
    assert [x["id"] for x in state["evidence"]] == ["server_log"]
    assert state["unlocked_locations"] == ["Interview Room"]


def test_sarah_withholds_witness_without_trust_or_badge(client):
    sid, _ = start(client)
    response = talk(client, sid, "sarah", "You are lying. Tell me what you saw near the server room.")
    assert response.status_code == 200
    assert "sarah_witness" not in ids(response)
    assert response.json()["new_evidence"] == []
    assert "threaten" in response.json()["reply"]


def test_sarah_reveals_only_after_respectful_trust_threshold(client):
    sid, _ = start(client)
    first = talk(client, sid, "sarah", "Please tell me about Mark's export plans.").json()
    assert first["state"]["trust"]["sarah"] == 52
    second = talk(client, sid, "sarah", "Could you tell me what you observed near the server corridor?").json()
    assert "sarah_witness" in {x["id"] for x in second["new_evidence"]}
    assert "I didn't see what was on it" in second["reply"]


def test_sarah_also_reveals_after_badge_is_presented(client):
    sid, _ = start(client)
    talk(client, sid, "alex", "What does the badge record show?")
    response = talk(client, sid, "sarah", "The badge record shows Ravi was there. What did you see?")
    assert "sarah_witness" in ids(response)


def test_mark_cannot_reveal_ravis_private_motive(client):
    sid, _ = start(client)
    response = talk(client, sid, "mark", "Why did Ravi copy the file?")
    assert "ravi_motive" not in ids(response)
    assert "private reasons" in response.json()["reply"]


def test_badge_question_does_not_award_unrelated_clues(client):
    sid, _ = start(client)
    response = talk(client, sid, "alex", "What does the badge reader show?")
    assert {"server_log", "badge_record"} == ids(response)
    assert "camera_loop" not in ids(response)


def test_ravi_motive_needs_both_clues_presented_to_him(client):
    sid, _ = start(client)
    talk(client, sid, "alex", "What does the badge record show?")
    talk(client, sid, "sarah", "Please tell me what you saw near the server.")
    response = talk(client, sid, "ravi", "Why did you copy the file?")
    assert "ravi_motive" not in ids(response)
    assert "Bring me a record" in response.json()["reply"]
    response = talk(client, sid, "ravi", "The badge record shows Ravi at 10:42. Sarah saw you with a USB. Why did you copy it?")
    assert "ravi_motive" in {x["id"] for x in response.json()["new_evidence"]}


def test_badge_record_unlocks_access_and_server_terminal(client):
    sid, state = start(client)
    talk(client, sid, "alex", "What does the entry record say?")
    move = client.post("/api/move", json={"session_id": sid, "location": "Server Floor"})
    assert move.status_code == 200
    examine = client.post("/api/examine", json={"session_id": sid, "object_id": "server_terminal"})
    assert "deleted_record" in {x["id"] for x in examine.json()["new_evidence"]}


def test_camera_requires_trust_or_respectful_approach(client):
    sid, _ = start(client)
    refused = talk(client, sid, "alex", "What happened with the camera footage?").json()
    assert "camera_loop" not in {x["id"] for x in refused["state"]["evidence"]}
    earned = talk(client, sid, "alex", "Please tell me about the camera override.").json()
    assert "camera_loop" in {x["id"] for x in earned["new_evidence"]}


def test_repeated_question_does_not_duplicate_evidence(client):
    sid, _ = start(client)
    talk(client, sid, "alex", "What does the badge record show?")
    repeated = talk(client, sid, "alex", "What does the badge record show?").json()
    assert repeated["new_evidence"] == []
    assert len(repeated["state"]["evidence"]) == 2
    assert "already" in repeated["reply"]


def test_plain_language_witness_question_routes_to_sarah_without_bypassing_gate(client):
    sid, _ = start(client)

    response = talk(client, sid, "sarah", "Did you see Ravi carrying a USB?").json()

    assert response["intent"] == "witness"
    assert response["new_evidence"] == []
    assert "badge record" in response["reply"].lower() or "trust" in response["reply"].lower()


def test_camera_access_question_gets_alexs_limited_record_answer(client):
    sid, _ = start(client)

    response = talk(client, sid, "alex", "Please tell me who could access the camera.").json()

    assert response["intent"] == "camera_loop"
    assert "camera_loop" in {item["id"] for item in response["new_evidence"]}
    assert "mark's office" in response["reply"].lower()
    assert "not who pressed" in response["reply"].lower()


def test_ravi_corridor_question_does_not_reveal_his_private_motive(client):
    sid, _ = start(client)

    response = talk(client, sid, "ravi", "Why did you enter the corridor?").json()

    assert response["intent"] == "timeline"
    assert "ravi_motive" not in {item["id"] for item in response["state"]["evidence"]}
    assert "private reason" not in response["reply"].lower()


def test_mark_alibi_question_gets_a_different_limited_answer(client):
    sid, _ = start(client)

    response = talk(client, sid, "mark", "Where were you around 10:40?").json()

    assert response["intent"] == "timeline"
    assert "my office" in response["reply"].lower()
    assert "badge and camera records" in response["reply"].lower()


def test_already_discovered_clue_is_never_reported_as_new(client):
    sid, _ = start(client)
    first = talk(client, sid, "alex", "What does the badge record show?").json()
    assert [e["id"] for e in first["new_evidence"]] == ["badge_record"]
    second = talk(client, sid, "alex", "Could you explain the badge reader entry?").json()
    assert second["new_evidence"] == []


def test_only_explicitly_named_clue_is_remembered_as_presented(client):
    sid, _ = start(client)
    talk(client, sid, "alex", "What does the badge reader show?")
    vague = talk(client, sid, "ravi", "The badge is important. What do you think?").json()
    assert vague["presented_evidence"] == []
    talk(client, sid, "ravi", "Where were you around 10:40 last night?")
    cited = talk(client, sid, "ravi", "The badge record shows your entry at 10:42. Explain that discrepancy.").json()
    assert "badge_record" in cited["presented_evidence"]
    assert cited["intent"] == "challenge"
    assert "contradicts" in cited["reply"] or "excuse" in cited["reply"]


def test_mark_does_not_admit_or_award_motive_from_broad_keyword(client):
    sid, _ = start(client)
    broad = talk(client, sid, "mark", "Tell me more about exports.").json()
    assert "motive" not in {e["id"] for e in broad["new_evidence"]}
    assert "motive" not in ids(broad)
    direct_low_trust = talk(client, sid, "mark", "Please tell me about the employee export.").json()
    assert "motive" not in {e["id"] for e in direct_low_trust["new_evidence"]}
    assert "motive" not in ids(direct_low_trust)
    qualified = talk(client, sid, "mark", "Could you explain the export plans?").json()
    assert "motive" in {e["id"] for e in qualified["new_evidence"]}


def test_multi_part_question_answers_bounded_parts(client):
    sid, _ = start(client)
    response = talk(client, sid, "sarah", "Please tell me what you noticed near the server room, and what Mark was pushing for.").json()
    assert response["intent"] == "witness"
    assert len(response["topics"]) >= 2
    assert "small metal USB" in response["reply"]
    assert "export" in response["reply"]
    assert {e["id"] for e in response["new_evidence"]} == {"sarah_witness"}


def test_follow_up_uses_last_topic_and_ambiguous_question_clarifies(client):
    sid, _ = start(client)
    first = talk(client, sid, "ravi", "Where were you working late?").json()
    follow = talk(client, sid, "ravi", "Why?").json()
    assert first["intent"] == follow["intent"] == "timeline"
    assert follow["topics"] == ["timeline"]
    vague = talk(client, sid, "sarah", "Tell me more.").json()
    assert vague["intent"] == "unclear"
    assert "Do you mean" in vague["reply"]


def test_irrelevant_question_and_npc_knowledge_limits(client):
    sid, _ = start(client)
    unrelated = talk(client, sid, "alex", "What music do you like?").json()
    assert unrelated["new_evidence"] == []
    sarah = talk(client, sid, "sarah", "What did you see inside the server terminal?").json()
    assert "don't know" in sarah["reply"] or "can't verify" in sarah["reply"]
    assert "deleted_record" not in ids(sarah)


def test_case_board_distinguishes_claim_observation_and_record(client):
    sid, _ = start(client)
    talk(client, sid, "ravi", "Where were you working late?")
    state = client.get(f"/api/game/{sid}").json()["state"]
    assert state["case_board"]["claims"]
    assert state["case_board"]["verified_facts"]
    assert state["evidence"][0]["discovery"]["method"] == "opening briefing"


def test_mark_admission_requires_archive_ledger_or_meaningful_trust(client):
    sid, _ = start(client)
    talk(client, sid, "alex", "Could you tell me the badge record?")
    talk(client, sid, "sarah", "Please tell me what you observed near the server room.")
    talk(client, sid, "alex", "Please tell me about the camera override.")
    assert client.post("/api/move", json={"session_id":sid,"location":"Records Archive"}).status_code == 200
    assert client.post("/api/examine", json={"session_id":sid,"object_id":"archive_ledger"}).status_code == 200
    assert client.post("/api/move", json={"session_id":sid,"location":"Interview Room"}).status_code == 200
    shown=talk(client,sid,"mark","The approval ledger shows an unauthorized employee-data export. What did you approve?").json()
    assert "mark_authorization" in shown["presented_evidence"]
    assert "motive" in {e["id"] for e in shown["new_evidence"]}


def test_case_048_is_locked_until_case_047_is_solved(client):
    sid, _ = start(client)
    assert client.post("/api/next_case", json={"session_id": sid}).status_code == 403
    main.SESSIONS[sid]["ending"] = {"type": "solved"}
    next_case = client.post("/api/next_case", json={"session_id": sid}).json()
    assert next_case["state"]["case_id"] == "048"
    assert next_case["state"]["case_subject"] == "BOARDROOM RECORDING ERASED"
    assert [x["id"] for x in next_case["state"]["evidence"]] == ["c2_brief"]


def test_case_048_runs_its_own_evidence_and_accusation_flow(client):
    sid, _ = start(client)
    main.SESSIONS[sid]["ending"] = {"type": "solved"}
    sid = client.post("/api/next_case", json={"session_id": sid}).json()["session_id"]
    def ask(npc, message):
        response = talk(client, sid, npc, message)
        assert response.status_code == 200, response.text
        return response.json()
    assert "c2_badge" in {x["id"] for x in ask("alex", "Who entered the boardroom?")["new_evidence"]}
    assert "c2_sarah" in {x["id"] for x in ask("sarah", "The badge record shows Mark entered. What did you hear at the meeting?")["new_evidence"]}
    assert "c2_camera" in {x["id"] for x in ask("alex", "Please tell me about the recorder trace.")["new_evidence"]}
    assert client.post("/api/move", json={"session_id": sid, "location": "Server Floor"}).status_code == 200
    assert "c2_deleted" in {x["id"] for x in client.post("/api/examine", json={"session_id": sid, "object_id": "server_terminal"}).json()["new_evidence"]}
    assert client.post("/api/move", json={"session_id": sid, "location": "Records Archive"}).status_code == 200
    assert "c2_mark_order" in {x["id"] for x in client.post("/api/examine", json={"session_id": sid, "object_id": "archive_ledger"}).json()["new_evidence"]}
    assert client.post("/api/move", json={"session_id": sid, "location": "Interview Room"}).status_code == 200
    mark = ask("mark", "The removal request shows your order. Why did you erase the recording?")
    assert "c2_mark_motive" in {x["id"] for x in mark["new_evidence"]}
    result = client.post("/api/accuse", json={"session_id": sid, "suspect_id": "mark", "supporting_evidence": ["c2_badge", "c2_sarah", "c2_mark_order", "c2_mark_motive"], "reason": "Mark ordered the recording erased to suppress the complaint evidence."}).json()
    assert result["type"] == "solved"
    assert result["culprit"] == "mark"
    main.SESSIONS.clear(); main.load_sessions()
    restored = client.get(f"/api/game/{sid}").json()["state"]
    assert restored["case_id"] == "048"
    assert restored["ending"]["type"] == "solved"


@pytest.mark.parametrize("question", ["Could you explain the keycard entry?", "Which employee badge entered the corridor?"])
def test_rephrased_questions_find_badge_intent(client, question):
    sid, _ = start(client)
    response = talk(client, sid, "alex", question)
    assert response.json()["intent"] == "badge_record"
    assert "badge_record" in ids(response)


def test_alex_does_not_know_ravis_motive(client):
    sid, _ = start(client)
    response = talk(client, sid, "alex", "Why did Ravi copy the employee file?")
    assert "ravi_motive" not in ids(response)
    assert "why Ravi copied it" in response.json()["reply"]


def test_showing_camera_evidence_changes_marks_response(client):
    sid, _ = start(client)
    talk(client, sid, "alex", "Please tell me about the camera loop.")
    response = talk(client, sid, "mark", "The camera override came from your office.")
    assert "camera_loop" in response.json()["presented_evidence"]
    assert "scheduling decision" in response.json()["reply"]


def test_memory_and_trust_persist_after_reload(client, tmp_path):
    sid, _ = start(client)
    talk(client, sid, "sarah", "Please tell me about Mark's export.")
    expected = main.SESSIONS[sid]["memory"]["sarah"]["questions"][:]
    main.SESSIONS.clear()
    main.load_sessions()
    restored = client.get(f"/api/game/{sid}").json()["state"]
    assert main.SESSIONS[sid]["memory"]["sarah"]["questions"] == expected
    assert restored["trust"]["sarah"] == 52


def test_trust_is_bounded_and_hostility_changes_behavior(client):
    sid, _ = start(client)
    for i in range(20):
        talk(client, sid, "sarah", f"You are lying, tell me what you saw number {i}.")
    state = client.get(f"/api/game/{sid}").json()["state"]
    assert 0 <= state["trust"]["sarah"] <= 100
    assert state["trust"]["sarah"] == 0
    assert main.SESSIONS[sid]["memory"]["sarah"]["threats"]


def test_objectives_and_location_unlocks_follow_clues(client):
    sid, _ = start(client)
    talk(client, sid, "alex", "What does the badge record show?")
    state = client.get(f"/api/game/{sid}").json()["state"]
    assert "Server Floor" in state["unlocked_locations"]
    assert not state["objectives"]["access_verified"]
    client.post("/api/move", json={"session_id":sid,"location":"Server Floor"})
    client.post("/api/examine", json={"session_id":sid,"object_id":"server_terminal"})
    assert client.get(f"/api/game/{sid}").json()["state"]["objectives"]["access_verified"]


def test_hotspots_require_correct_location_and_prerequisite(client):
    sid, _ = start(client)
    bad_location = client.post("/api/examine", json={"session_id":sid,"object_id":"archive_ledger"})
    assert bad_location.status_code == 403
    locked = client.post("/api/move", json={"session_id":sid,"location":"Server Floor"})
    assert locked.status_code == 403


def test_happy_path_case_solves_with_explicit_evidence(client):
    sid, _ = start(client)
    talk(client, sid, "alex", "What does the badge record show?")
    talk(client, sid, "sarah", "Please tell me what you noticed near the server room.")
    talk(client, sid, "mark", "Please tell me about the employee export.")
    talk(client, sid, "mark", "Could you explain the export plans?")
    talk(client, sid, "ravi", "The badge record shows Ravi at 10:42; Sarah saw him with a USB. Why did you copy it?")
    case = client.get(f"/api/game/{sid}").json()["state"]["evidence"]
    support=[x["id"] for x in case if x["id"] in ("badge_record","sarah_witness","ravi_motive","motive")]
    reason="Ravi copied the file: the badge record and Sarah's USB witness contradict his maintenance timeline. Mark planned the sale, while Ravi says he copied it to preserve proof."
    outcome=client.post("/api/accuse",json={"session_id":sid,"suspect_id":"ravi","supporting_evidence":support,"reason":reason}).json()
    assert outcome["type"]=="solved"
    assert all(item["passed"] for item in outcome["checks"])


def test_wrong_and_weak_accusations_are_distinguished(client):
    sid, _ = start(client)
    talk(client, sid, "alex", "What does the badge record show?")
    talk(client, sid, "sarah", "Please tell me what you saw near the server.")
    weak=client.post("/api/accuse",json={"session_id":sid,"suspect_id":"ravi","supporting_evidence":["badge_record"]}).json()
    assert weak["type"]=="correct_weak"
    sid2, _=start(client)
    talk(client, sid2, "alex", "What does the badge record show?")
    talk(client, sid2, "sarah", "Please tell me what you saw near the server.")
    wrong=client.post("/api/accuse",json={"session_id":sid2,"suspect_id":"mark","supporting_evidence":["badge_record","sarah_witness"]}).json()
    assert wrong["type"]=="wrong"


def test_insufficient_case_and_unsupported_evidence(client):
    sid, _=start(client)
    outcome=client.post("/api/accuse",json={"session_id":sid,"suspect_id":"ravi"}).json()
    assert outcome["type"]=="insufficient"
    invalid=client.post("/api/accuse",json={"session_id":sid,"suspect_id":"ravi","supporting_evidence":["badge_record"]})
    assert invalid.status_code==422


def test_closed_case_rejects_further_dialogue(client):
    sid, _=start(client)
    talk(client,sid,"alex","What does the badge record show?")
    talk(client,sid,"sarah","Please tell me what you saw near the server.")
    client.post("/api/accuse",json={"session_id":sid,"suspect_id":"ravi","supporting_evidence":["badge_record","sarah_witness"]})
    assert talk(client,sid,"ravi","Where were you?").status_code==409


@pytest.mark.parametrize("payload,status",[
    ({"session_id":"invalid","npc_id":"ravi","message":"hi"},422),
    ({"session_id":str(uuid.uuid4()),"npc_id":"ghost","message":"hi"},404),
    ({"session_id":str(uuid.uuid4()),"npc_id":"ravi","message":"x"*601},422),
])
def test_invalid_session_npc_and_oversized_message(client,payload,status):
    assert client.post("/api/talk",json=payload).status_code==status


def test_invalid_suspect(client):
    sid,_=start(client)
    assert client.post("/api/accuse",json={"session_id":sid,"suspect_id":"ghost"}).status_code==400


def test_invalid_model_intent_schema_is_rejected():
    with pytest.raises(Exception):
        main.Intent.model_validate({"intent":"invented_secret","tone":"neutral","references":[]})
    assert main.fallback_intent("Could you check the badge reader?","alex",["server_log"]).intent=="badge_record"


def fake_openai_module(completion):
    class Completions:
        async def create(self, **_kwargs):
            if isinstance(completion, BaseException):
                raise completion
            return completion
    class AsyncOpenAI:
        def __init__(self, **_kwargs):
            self.chat=types.SimpleNamespace(completions=Completions())
    module=types.ModuleType("openai")
    module.AsyncOpenAI=AsyncOpenAI
    return module


def test_provider_timeout_falls_back_to_rules(client,monkeypatch):
    monkeypatch.setattr(main,"openai_available",lambda:True)
    monkeypatch.setenv("OPENAI_API_KEY","test-key")
    monkeypatch.setitem(sys.modules,"openai",fake_openai_module(TimeoutError("simulated timeout")))
    sid,_=start(client)
    response=talk(client,sid,"alex","What does the badge record show?")
    assert response.status_code==200
    assert response.json()["intent_mode"]=="local-rules"
    assert response.json()["dialogue_mode"]=="offline-fallback"
    assert "unavailable" in response.json()["dialogue_warning"].lower()
    assert "badge_record" in ids(response)


def test_malformed_provider_output_falls_back_to_rules(client,monkeypatch):
    malformed=types.SimpleNamespace(choices=[types.SimpleNamespace(message=types.SimpleNamespace(content=""))])
    monkeypatch.setattr(main,"openai_available",lambda:True)
    monkeypatch.setenv("OPENAI_API_KEY","test-key")
    monkeypatch.setitem(sys.modules,"openai",fake_openai_module(malformed))
    sid,_=start(client)
    response=talk(client,sid,"alex","Could you check the keycard entry?")
    assert response.status_code==200
    assert response.json()["dialogue_mode"]=="offline-fallback"
    assert response.json()["intent"]=="badge_record"


def test_generated_dialogue_uses_local_rules_for_gameplay(client,monkeypatch):
    generated=types.SimpleNamespace(choices=[types.SimpleNamespace(message=types.SimpleNamespace(content="I maintain the building's access and camera records."))])
    monkeypatch.setattr(main,"openai_available",lambda:True)
    monkeypatch.setenv("OPENAI_API_KEY","test-key")
    monkeypatch.setitem(sys.modules,"openai",fake_openai_module(generated))
    sid,_=start(client)

    response=talk(client,sid,"alex","What is your job?").json()

    assert response["intent_mode"]=="local-rules"
    assert response["dialogue_mode"]=="openai"
    assert response["intent"]=="identity"
    assert "maintain" in response["reply"].lower()


def test_vague_repeated_and_aggressive_routes(client):
    sid,_=start(client)
    vague=talk(client,sid,"ravi","Tell me more.").json()
    assert vague["intent"]=="unclear"
    aggressive=talk(client,sid,"ravi","You are lying. Where were you last night?").json()
    assert aggressive["trust_delta"]==-8
    repeated=talk(client,sid,"ravi","You are lying. Where were you last night?").json()
    assert repeated["trust_delta"]==-2 and "already" in repeated["reply"]


def test_unrelated_questions_never_grant_clues(client):
    sid,_=start(client)
    response=talk(client,sid,"alex","What is your favorite color today?").json()
    assert response["new_evidence"]==[]
    assert {x["id"] for x in response["state"]["evidence"]}=={"server_log"}


def test_offline_mode_is_reported(client,monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY",raising=False)
    monkeypatch.delenv("GEMINI_API_KEY",raising=False)
    assert client.get("/api/health").json()["mode"]=="offline"
    sid,state=start(client)
    assert "Offline" in state["mode"]


def test_gemini_configuration_uses_compatible_endpoint(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY",raising=False)
    monkeypatch.setenv("GEMINI_API_KEY","test-gemini-key")
    monkeypatch.setenv("GEMINI_MODEL","gemini-test-model")

    config=main.ai_provider_config()

    assert config["provider"]=="gemini"
    assert config["model"]=="gemini-test-model"
    assert config["base_url"]=="https://generativelanguage.googleapis.com/v1beta/openai/"


def test_gemini_credentials_take_precedence_when_both_providers_exist(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY","test-openai-key")
    monkeypatch.setenv("GEMINI_API_KEY","test-gemini-key")

    assert main.ai_provider_config()["provider"]=="gemini"


@pytest.mark.parametrize(("npc","question","expected"),[
    ("ravi","Who are you?","IT Administrator"),
    ("sarah","What do you do?","People Operations"),
    ("alex","How do you know Mark?","Mark manages a department"),
])
def test_identity_and_relationship_questions_get_direct_answers(client,npc,question,expected):
    sid,_=start(client)

    response=talk(client,sid,npc,question).json()

    assert expected.lower() in response["reply"].lower()
    assert response["new_evidence"]==[]


def test_generated_dialogue_receives_npc_context_without_authored_answer(monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY",raising=False)
    monkeypatch.delenv("GEMINI_MODEL",raising=False)
    state=main.fresh_state("047")
    state["memory"]["alex"]["answers"]=[{"question":"Earlier access question","answer":"Earlier access answer"}]
    state["memory"]["sarah"]["answers"]=[{"question":"Sarah private question","answer":"Sarah private answer"}]
    captured={}
    completion=types.SimpleNamespace(choices=[types.SimpleNamespace(message=types.SimpleNamespace(content="I maintain the building access and camera records."))])
    class Completions:
        async def create(self,**kwargs):
            captured.update(kwargs)
            return completion
    class AsyncOpenAI:
        def __init__(self,**_kwargs):self.chat=types.SimpleNamespace(completions=Completions())
    module=types.ModuleType("openai");module.AsyncOpenAI=AsyncOpenAI
    monkeypatch.setitem(sys.modules,"openai",module)
    monkeypatch.setenv("OPENAI_API_KEY","test-key")
    monkeypatch.setattr(main,"openai_available",lambda:True)

    reply,mode=asyncio.run(main.render_npc_reply(state,"alex","What do you do?","identity","hold_boundary","Authored fallback that must not enter the prompt."))
    prompt=captured["messages"][0]["content"]

    assert mode=="openai"
    assert reply=="I maintain the building access and camera records."
    assert "Earlier access question" in prompt
    assert "Sarah private question" not in prompt
    assert "known_facts_the_npc_may_share" in prompt
    assert "verified_relevant_evidence_found_by_player" in prompt
    assert "Authored fallback that must not enter the prompt." not in prompt
    assert "camera_loop" not in prompt
    assert captured["messages"][-1]["content"]=="What do you do?"
    assert "response_format" not in captured


def test_npc_dialogue_context_respects_knowledge_and_evidence_gates():
    state=main.fresh_state("047")
    context=main.npc_dialogue_context(state,"ravi","ravi_motive")
    npc=context["npc"]
    assert "He copied the file and deleted a later audit row" not in npc["known_facts_the_npc_may_share"]
    assert not npc["personal_secrets_the_npc_may_share_now"]

    main.add_clue(state,"badge_record","alex")
    main.add_clue(state,"sarah_witness","sarah")
    context=main.npc_dialogue_context(state,"ravi","ravi_motive")
    assert "He copied the file and deleted a later audit row" in context["npc"]["known_facts_the_npc_may_share"]
    assert "He copied the file to preserve proof of Mark's sale" in context["npc"]["personal_secrets_the_npc_may_share_now"]


def test_case2_dialogue_context_contains_only_current_npc_history_and_relevant_found_evidence():
    state=main.fresh_state("048")
    main.add_case2_clue(state,"c2_badge","alex")
    state["memory"]["alex"]["presented_evidence"]=["c2_badge"]
    state["memory"]["alex"]["answers"]=[{"question":"Prior Alex question","answer":"Prior Alex answer"}]
    state["memory"]["sarah"]["answers"]=[{"question":"Sarah's private question","answer":"Private"}]

    context=main.npc_dialogue_context(state,"alex","access")

    assert context["verified_relevant_evidence_found_by_player"][0]["id"]=="c2_badge"
    assert context["verified_relevant_evidence_found_by_player"][0]["shown_to_this_npc"] is True
    assert context["this_npc_recent_conversation"][0]["question"]=="Prior Alex question"
    assert "Sarah's private question" not in str(context)
    assert "recorder maintenance" in context["npc"]["knowledge_boundaries"]


def test_live_strategy_learning_is_saved_per_session_and_npc():
    state=main.fresh_state("047")
    key=main.AI_LAB.strategy_state(state,"alex","neutral")
    strategy,_=main.AI_LAB.opponent_strategy(state,"alex","neutral")
    scores=state["strategy_learning"]["alex"][key]
    before=scores[strategy]

    main.AI_LAB.record_strategy_outcome(state,"alex",key,"neutral",strategy,3.0)

    assert scores[strategy]>before
    restored=main.migrate_state(state)
    assert restored["strategy_learning"]["alex"][key][strategy]==scores[strategy]
    other_session=main.fresh_state("047")
    assert other_session["strategy_learning"]=={}


def test_strategy_learning_does_not_append_unrelated_copy_to_npc_reply(client,monkeypatch):
    monkeypatch.setattr(main.AI_LAB,"opponent_strategy",lambda *_:("offer_safe_fact","UNRELATED STRATEGY COPY"))
    sid,_=start(client)

    response=talk(client,sid,"alex","What is your favorite color?").json()

    assert "UNRELATED STRATEGY COPY" not in response["reply"]
    assert response["new_evidence"]==[]


def test_case_048_short_follow_up_stays_with_same_npc_topic(client):
    sid,_=start(client)
    main.SESSIONS[sid]["ending"]={"type":"solved"}
    sid=client.post("/api/next_case",json={"session_id":sid}).json()["session_id"]
    talk(client,sid,"alex","Who entered the boardroom?")
    first=talk(client,sid,"sarah","The badge record shows Mark entered. What did you hear?").json()
    follow=talk(client,sid,"sarah","Why?").json()

    assert first["intent"]=="witness"
    assert follow["intent"]=="witness"
    assert follow["new_evidence"]==[]
    assert "complaint review" in follow["reply"]
