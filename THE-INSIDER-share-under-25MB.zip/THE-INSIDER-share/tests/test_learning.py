import copy
import os
import shutil
import uuid

import pytest
import main


def run_without_event_loop(coroutine):
    try:
        coroutine.send(None)
    except StopIteration as result:
        return result.value
    raise AssertionError("The offline dialogue unexpectedly suspended for external I/O.")


@pytest.fixture
def clean_sessions(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.setattr(main, "openai_available", lambda: False)
    folder = os.path.join(os.path.dirname(__file__), ".learning-state-" + str(uuid.uuid4()))
    os.makedirs(folder)
    monkeypatch.setattr(main, "STATE_FILE", os.path.join(folder, "sessions.json"))
    main.SESSIONS.clear()
    yield
    main.SESSIONS.clear()
    shutil.rmtree(folder, ignore_errors=True)


def test_supervised_predictor_has_held_out_and_beats_baseline():
    metrics = main.AI_LAB.artifact["supervised"]
    assert metrics["episodes"] >= 1000
    assert metrics["test_examples"] > 0
    assert metrics["accuracy"] > metrics["baseline_accuracy"]


def test_q_learning_policy_beats_fixed_boundary_baseline():
    metrics = main.AI_LAB.artifact["q_learning"]
    assert metrics["episodes"] >= 10000
    assert len(metrics["reward_progression"]) >= 10
    assert metrics["learned_mean_reward"] > metrics["baseline_mean_reward"]


def test_live_talk_returns_prediction_and_adaptive_policy(clean_sessions):
    created = main.new_game()
    sid = created["session_id"]
    result = run_without_event_loop(main.talk(main.Talk(session_id=sid, npc_id="alex", message="Could you tell me what the badge record shows?")))
    assert result["npc_id"] == "alex"
    assert result["new_evidence"][0]["id"] == "badge_record"
    assert result["next_action_prediction"]["action"] in main.AI_LAB.artifact["supervised"]["labels"]
    assert result["opponent_strategy"] in main.AI_LAB.artifact["q_learning"]["valid_actions"]


def test_ai_dashboard_reports_training_and_real_session_outcomes(clean_sessions):
    sid = main.new_game()["session_id"]
    main.SESSIONS[sid]["ending"] = {"type": "solved"}
    metrics = main.ai_dashboard()
    assert metrics["supervised"]["test_examples"] > 0
    assert metrics["q_learning"]["evaluation_episodes"] > 0
    assert metrics["investigations"]["outcomes"].get("solved") == 1


def test_counterfactual_replay_does_not_change_actual_case(clean_sessions):
    sid = main.new_game()["session_id"]
    state = main.SESSIONS[sid]
    state["evidence"] = ["server_log", "badge_record", "sarah_witness", "ravi_motive", "motive"]
    state["ending"] = {"type": "solved", "title": "Actual ending"}
    before = copy.deepcopy(state)
    branch = main.counterfactual(main.Counterfactual(session_id=sid, suspect_id="mark", supporting_evidence=["badge_record", "sarah_witness"], reason="Mark planned the sale, but Ravi copied the file."))
    assert branch["simulated"] is True
    assert branch["alternate_outcome"]["type"] == "wrong"
    assert main.SESSIONS[sid] == before

