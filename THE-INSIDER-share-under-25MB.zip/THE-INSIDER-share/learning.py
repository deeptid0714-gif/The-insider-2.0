"""Small, dependency-free supervised and tabular Q-learning components.

The models learn only investigation action preferences and dialogue tactics.
Case facts, evidence awards, and accusation outcomes remain server rules.
"""
from __future__ import annotations

import json
import math
import os
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "models"
MODEL_FILE = MODEL_DIR / "insider_learning.json"
SEED = 481047
ACTION_LABELS = {
    "ask_security": "Ask Alex about access",
    "build_trust": "Build a witness's trust",
    "interview_witness": "Interview Sarah",
    "inspect_server": "Inspect the server records",
    "investigate_camera": "Investigate the camera record",
    "present_evidence": "Present evidence to a suspect",
    "review_case": "Review another lead",
    "accuse": "Prepare an accusation",
}
STRATEGY_COPY = {
    "deescalate": "Let's keep this grounded in what the records can prove.",
    "request_corroboration": "Show me the specific record you want me to address.",
    "offer_safe_fact": "I can start with what falls within my own role.",
    "hold_boundary": "I can only speak to what I know first-hand.",
}


def _stage(state: dict[str, Any]) -> str:
    evidence = set(state.get("evidence", []))
    if state.get("case_id") == "048":
        if "c2_badge" not in evidence:
            return "opening"
        if "c2_sarah" not in evidence:
            return "witness"
        if "c2_mark_order" not in evidence:
            return "records"
        return "theory"
    if "badge_record" not in evidence:
        return "opening"
    if "sarah_witness" not in evidence:
        return "witness"
    if "camera_loop" not in evidence:
        return "camera"
    if "deleted_record" not in evidence:
        return "records"
    return "theory"


def _player_style(actions: list[dict[str, Any]]) -> str:
    recent = actions[-8:]
    if not recent:
        return "mixed"
    hostile = sum(item.get("tone") == "hostile" for item in recent)
    respectful = sum(item.get("tone") == "respectful" for item in recent)
    evidence = sum(bool(item.get("references")) for item in recent)
    if hostile >= 2 and hostile > respectful:
        return "aggressive"
    if respectful >= 2 and respectful >= evidence:
        return "rapport"
    if evidence >= 1:
        return "systematic"
    return "mixed"


def _features(state: dict[str, Any], npc: str = "ravi") -> dict[str, str]:
    actions = state.get("action_log", [])
    trust = state.get("trust", {}).get(npc, 48)
    return {
        "stage": _stage(state),
        "style": _player_style(actions),
        "trust": "low" if trust < 40 else "high" if trust >= 65 else "mid",
        "location": state.get("location", "Interview Room"),
        "last_action": actions[-1].get("action", "start") if actions else "start",
        "npc": npc,
        "evidence_band": "none" if len(state.get("evidence", [])) < 2 else "some" if len(state.get("evidence", [])) < 5 else "many",
    }


def _next_action_distribution(features: dict[str, str]) -> list[tuple[str, float]]:
    stage, style = features["stage"], features["style"]
    if stage == "opening":
        if style == "rapport": return [("build_trust", .42), ("ask_security", .48), ("review_case", .10)]
        if style == "aggressive": return [("ask_security", .42), ("accuse", .28), ("review_case", .30)]
        return [("ask_security", .72), ("build_trust", .16), ("review_case", .12)]
    if stage == "witness":
        if style == "rapport": return [("interview_witness", .70), ("investigate_camera", .18), ("review_case", .12)]
        if style == "aggressive": return [("interview_witness", .34), ("accuse", .28), ("investigate_camera", .38)]
        return [("interview_witness", .55), ("inspect_server", .25), ("investigate_camera", .20)]
    if stage == "camera":
        return [("investigate_camera", .55 if style != "aggressive" else .35), ("inspect_server", .28), ("present_evidence", .17 if style != "aggressive" else .37)]
    if stage == "records":
        return [("inspect_server", .45), ("investigate_camera", .25), ("present_evidence", .30)]
    if style == "aggressive": return [("accuse", .55), ("present_evidence", .25), ("review_case", .20)]
    return [("present_evidence", .48), ("accuse", .25), ("review_case", .27)]


def _features_for_sim(stage: str, style: str, trust: str, location: str, last_action: str, npc: str, evidence_band: str) -> dict[str, str]:
    return {"stage": stage, "style": style, "trust": trust, "location": location, "last_action": last_action, "npc": npc, "evidence_band": evidence_band}


def _training_examples(seed: int = SEED, episodes: int = 3200) -> list[tuple[int, dict[str, str], str]]:
    rng = random.Random(seed)
    data: list[tuple[int, dict[str, str], str]] = []
    styles = ("systematic", "rapport", "aggressive", "mixed")
    for episode in range(episodes):
        style = rng.choice(styles)
        stage, trust, location, last, band = "opening", "mid", "Interview Room", "start", "none"
        for _ in range(rng.randint(5, 10)):
            features = _features_for_sim(stage, style, trust, location, last, rng.choice(("ravi", "sarah", "alex", "mark")), band)
            options = _next_action_distribution(features)
            roll = rng.random()
            chosen = options[-1][0]
            for action, probability in options:
                roll -= probability
                if roll <= 0:
                    chosen = action
                    break
            data.append((episode, features, chosen))
            last = chosen
            if chosen == "ask_security": stage, band = "witness", "some"
            elif chosen == "interview_witness": stage, band = "camera", "some"
            elif chosen == "investigate_camera": stage, band = "records", "some"
            elif chosen == "inspect_server":
                location, stage, band = "Server Floor", "theory", "many"
            elif chosen == "present_evidence": stage, band = "theory", "many"
            elif chosen == "build_trust": trust = "high"
            elif chosen == "accuse" and rng.random() < .55: stage = "opening"
            if location == "Server Floor" and rng.random() < .6:
                location = "Interview Room"
    return data


def _train_nb(train: list[tuple[int, dict[str, str], str]]) -> dict[str, Any]:
    class_counts: Counter[str] = Counter()
    feature_counts: dict[str, dict[str, Counter[str]]] = defaultdict(lambda: defaultdict(Counter))
    vocab: dict[str, set[str]] = defaultdict(set)
    for _, features, label in train:
        class_counts[label] += 1
        for key, value in features.items():
            feature_counts[label][key][value] += 1
            vocab[key].add(value)
    return {
        "classes": dict(class_counts),
        "features": {label: {key: dict(counts) for key, counts in by_feature.items()} for label, by_feature in feature_counts.items()},
        "vocabulary": {key: sorted(values) for key, values in vocab.items()},
    }


def _nb_predict(model: dict[str, Any], features: dict[str, str]) -> tuple[str, float]:
    total = sum(model["classes"].values())
    scores: dict[str, float] = {}
    for label, class_count in model["classes"].items():
        score = math.log(class_count / total)
        for key, value in features.items():
            counts = model["features"].get(label, {}).get(key, {})
            vocab_size = max(1, len(model["vocabulary"].get(key, [])))
            score += math.log((counts.get(value, 0) + 1) / (class_count + vocab_size))
        scores[label] = score
    best = max(scores, key=scores.get)
    exp_scores = {key: math.exp(value - max(scores.values())) for key, value in scores.items()}
    confidence = exp_scores[best] / sum(exp_scores.values())
    return best, confidence


def _rl_state(style: str, stage: str, trust: str, tone: str) -> str:
    return "|".join((style, stage, trust, tone))


def _valid_strategies(tone: str) -> tuple[str, ...]:
    if tone == "hostile":
        return ("deescalate", "hold_boundary", "request_corroboration")
    return ("request_corroboration", "offer_safe_fact", "hold_boundary")


def _rl_reward(strategy: str, style: str, stage: str, trust: str, tone: str) -> float:
    # Reward a fair, useful interview; do not reward disclosure that violates canon.
    if strategy == "deescalate":
        return 4.0 if tone == "hostile" else -1.0
    if strategy == "request_corroboration":
        return 3.0 if style == "systematic" or stage in ("witness", "records") else 1.0
    if strategy == "offer_safe_fact":
        return 3.0 if style == "rapport" and trust != "low" else 1.0
    if strategy == "hold_boundary":
        return 1.5 if tone == "hostile" else (-1.0 if stage == "opening" else 0.0)
    return 0.0


class LearningLab:
    def __init__(self) -> None:
        self.runtime_inferences = 0
        self.runtime_predictions: list[dict[str, Any]] = []
        self.runtime_strategy_counts: Counter[str] = Counter()
        self.artifact = self._load_or_train()

    def retrain(self) -> dict[str, Any]:
        """Run both reproducible simulations again and replace the saved policy artifact."""
        self.artifact = self._train()
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        MODEL_FILE.write_text(json.dumps(self.artifact, indent=2), encoding="utf-8")
        return self.artifact

    def _load_or_train(self) -> dict[str, Any]:
        try:
            with MODEL_FILE.open(encoding="utf-8") as handle:
                artifact = json.load(handle)
            if artifact.get("version") == 1 and artifact.get("supervised", {}).get("model") and artifact.get("q_table"):
                return artifact
        except (OSError, json.JSONDecodeError, TypeError):
            pass
        artifact = self._train()
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        MODEL_FILE.write_text(json.dumps(artifact, indent=2), encoding="utf-8")
        return artifact

    def _train(self) -> dict[str, Any]:
        data = _training_examples()
        episodes = max(item[0] for item in data) + 1
        train = [item for item in data if item[0] < int(episodes * .8)]
        test = [item for item in data if item[0] >= int(episodes * .8)]
        model = _train_nb(train)
        baseline_label = Counter(label for _, _, label in train).most_common(1)[0][0]
        accuracy = sum(_nb_predict(model, features)[0] == label for _, features, label in test) / len(test)
        baseline = sum(baseline_label == label for _, _, label in test) / len(test)
        q_table, q_metrics = self._train_q()
        return {
            "version": 1,
            "seed": SEED,
            "supervised": {"model": model, "episodes": episodes, "train_examples": len(train), "test_examples": len(test), "accuracy": round(accuracy, 4), "baseline_accuracy": round(baseline, 4), "baseline": "most frequent training label", "labels": ACTION_LABELS},
            "q_learning": q_metrics,
            "q_table": q_table,
        }

    def _train_q(self) -> tuple[dict[str, dict[str, float]], dict[str, Any]]:
        rng = random.Random(SEED + 48)
        q: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
        episodes, alpha, gamma = 18000, .18, .82
        checkpoints: list[dict[str, float]] = []
        window: list[float] = []
        styles, stages, trusts = ("systematic", "rapport", "aggressive", "mixed"), ("opening", "witness", "camera", "records", "theory"), ("low", "mid", "high")
        for episode in range(episodes):
            style, stage, trust = rng.choice(styles), rng.choice(stages), rng.choice(trusts)
            cumulative = 0.0
            for turn in range(5):
                tone = "hostile" if style == "aggressive" and rng.random() < .58 else "respectful" if style == "rapport" and rng.random() < .62 else "neutral"
                state = _rl_state(style, stage, trust, tone)
                choices = _valid_strategies(tone)
                epsilon = max(.04, .35 * (1 - episode / episodes))
                if rng.random() < epsilon:
                    action = rng.choice(choices)
                else:
                    action = max(choices, key=lambda name: q[state].get(name, 0.0))
                reward = _rl_reward(action, style, stage, trust, tone) + rng.uniform(-.12, .12)
                next_style = "rapport" if action == "deescalate" else "systematic" if action == "request_corroboration" and stage != "opening" else style
                next_trust = "high" if action in ("deescalate", "offer_safe_fact") else trust
                next_stage = stages[min(stages.index(stage) + (1 if action == "request_corroboration" and stage in ("witness", "records") else 0), len(stages) - 1)]
                next_state = _rl_state(next_style, next_stage, next_trust, "neutral")
                next_actions = _valid_strategies("neutral")
                future = max(q[next_state].get(item, 0.0) for item in next_actions)
                old = q[state].get(action, 0.0)
                q[state][action] = old + alpha * (reward + gamma * future - old)
                cumulative += reward
                style, stage, trust = next_style, next_stage, next_trust
            window.append(cumulative)
            if (episode + 1) % 1000 == 0:
                checkpoints.append({"episode": episode + 1, "mean_reward": round(sum(window[-1000:]) / min(1000, len(window)), 3)})
        q_plain = {state: dict(values) for state, values in q.items()}
        learned, baseline = self._evaluate_q(q_plain)
        return q_plain, {"episodes": episodes, "alpha": alpha, "gamma": gamma, "states_learned": len(q_plain), "valid_actions": sorted({action for actions in q_plain.values() for action in actions}), "reward_progression": checkpoints, "evaluation_episodes": 1200, "learned_mean_reward": round(learned, 3), "baseline_mean_reward": round(baseline, 3), "baseline": "always hold boundary", "improvement": round(learned - baseline, 3)}

    @staticmethod
    def _evaluate_q(q: dict[str, dict[str, float]]) -> tuple[float, float]:
        rng = random.Random(SEED + 99)
        rewards, baseline_rewards = [], []
        for _ in range(1200):
            style = rng.choice(("systematic", "rapport", "aggressive", "mixed"))
            stage = rng.choice(("opening", "witness", "camera", "records", "theory"))
            trust = rng.choice(("low", "mid", "high"))
            tone = "hostile" if style == "aggressive" and rng.random() < .58 else "respectful" if style == "rapport" and rng.random() < .62 else "neutral"
            state = _rl_state(style, stage, trust, tone)
            actions = _valid_strategies(tone)
            action = max(actions, key=lambda item: q.get(state, {}).get(item, 0.0))
            rewards.append(_rl_reward(action, style, stage, trust, tone))
            baseline_rewards.append(_rl_reward("hold_boundary", style, stage, trust, tone))
        return sum(rewards) / len(rewards), sum(baseline_rewards) / len(baseline_rewards)

    def predict_next(self, state: dict[str, Any], npc: str) -> dict[str, Any]:
        self.runtime_inferences += 1
        features = _features(state, npc)
        label, confidence = _nb_predict(self.artifact["supervised"]["model"], features)
        row = {"prediction": label, "confidence": round(confidence, 3)}
        self.runtime_predictions.append(row)
        self.runtime_predictions = self.runtime_predictions[-100:]
        return {"action": label, "label": ACTION_LABELS.get(label, label), "confidence": round(confidence, 3)}

    def opponent_strategy(self, state: dict[str, Any], npc: str, tone: str) -> tuple[str, str]:
        key = self.strategy_state(state, npc, tone)
        effective_tone = tone if tone in ("hostile", "respectful") else "neutral"
        actions = _valid_strategies(effective_tone)
        trained = self.artifact["q_table"].get(key, {})
        learned = state.setdefault("strategy_learning", {}).setdefault(npc, {}).setdefault(key, {})
        for candidate in actions:
            learned.setdefault(candidate, trained.get(candidate, 0.0))
        action = max(actions, key=lambda item: learned.get(item, trained.get(item, 0.0)))
        self.runtime_strategy_counts[action] += 1
        return action, STRATEGY_COPY[action]

    @staticmethod
    def strategy_state(state: dict[str, Any], npc: str, tone: str) -> str:
        features = _features(state, npc)
        effective_tone = tone if tone in ("hostile", "respectful") else "neutral"
        return _rl_state(features["style"], features["stage"], features["trust"], effective_tone)

    def record_strategy_outcome(self, state: dict[str, Any], npc: str, key: str, tone: str, action: str, reward: float) -> None:
        if action not in STRATEGY_COPY:
            return
        effective_tone = tone if tone in ("hostile", "respectful") else "neutral"
        actions = _valid_strategies(effective_tone)
        trained = self.artifact["q_table"].get(key, {})
        learned = state.setdefault("strategy_learning", {}).setdefault(npc, {}).setdefault(key, {})
        for candidate in actions:
            learned.setdefault(candidate, trained.get(candidate, 0.0))
        future = max(learned.get(candidate, trained.get(candidate, 0.0)) for candidate in actions)
        old = learned.get(action, trained.get(action, 0.0))
        learned[action] = old + .2 * (max(-3.0, min(3.0, reward)) + .7 * future - old)

    @staticmethod
    def record_action(state: dict[str, Any], action: str, tone: str = "neutral", references: list[str] | None = None) -> None:
        telemetry = state.setdefault("ai_telemetry", {"live_correct": 0, "live_total": 0, "pending_prediction": None})
        pending = telemetry.get("pending_prediction")
        if pending:
            telemetry["live_total"] = telemetry.get("live_total", 0) + 1
            telemetry["live_correct"] = telemetry.get("live_correct", 0) + int(pending.get("action") == action)
        telemetry["pending_prediction"] = None
        log = state.setdefault("action_log", [])
        log.append({"action": action, "tone": tone, "references": references or []})
        state["action_log"] = log[-100:]

    @staticmethod
    def set_pending_prediction(state: dict[str, Any], prediction: dict[str, Any]) -> None:
        state.setdefault("ai_telemetry", {"live_correct": 0, "live_total": 0, "pending_prediction": None})["pending_prediction"] = prediction

    def dashboard(self, sessions: dict[str, dict[str, Any]]) -> dict[str, Any]:
        endings = [session.get("ending") for session in sessions.values() if session.get("ending")]
        outcome_counts = Counter(item.get("type", "unknown") for item in endings)
        live_total = sum(session.get("ai_telemetry", {}).get("live_total", 0) for session in sessions.values())
        live_correct = sum(session.get("ai_telemetry", {}).get("live_correct", 0) for session in sessions.values())
        sup = self.artifact["supervised"]
        q = self.artifact["q_learning"]
        return {
            "supervised": {k: sup[k] for k in ("episodes", "train_examples", "test_examples", "accuracy", "baseline_accuracy", "baseline", "labels")},
            "q_learning": q,
            "runtime": {"inferences_this_process": self.runtime_inferences, "opponent_decisions": sum(self.runtime_strategy_counts.values()), "strategy_counts": dict(self.runtime_strategy_counts), "live_predictions_scored": live_total, "live_correct": live_correct, "live_accuracy": round(live_correct / live_total, 4) if live_total else None},
            "investigations": {"total_completed": len(endings), "outcomes": dict(outcome_counts)},
            "model_file": str(MODEL_FILE.relative_to(ROOT)).replace("\\", "/"),
            "case_rules_remain_authoritative": True,
        }
