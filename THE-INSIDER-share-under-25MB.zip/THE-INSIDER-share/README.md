# THE INSIDER

**THE INSIDER is a playable 2D noir investigation game.** Move through an illustrated office, choose who to interview, ask questions in natural language, collect evidence, unlock new rooms, and make a supported accusation. It is a game with an in-world scene and interactive investigation, not a static chat page.

## Run on Windows

Open PowerShell in the project folder:

```powershell
cd "C:\path\to\THE-INSIDER-share"
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
uvicorn main:app --reload
```

Open `http://localhost:8000`. The game opens at its local investigator sign-in. The codename is remembered in this browser, while each page load starts the current case from its opening scene. This profile is local to the browser; it is not a secure online account. The case and API are served from the same local FastAPI process. Gemini and OpenAI are optional; leaving both keys blank runs the complete deterministic offline game. To use Gemini, copy `.env.example` to `.env` and add your server-side key:

```text
GEMINI_API_KEY=your-server-side-key
GEMINI_MODEL=gemini-3.8-flash
```

For OpenAI instead, set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in `.env`. Gemini uses Google's OpenAI-compatible endpoint through the existing OpenAI Python SDK. Never put an API key in browser code or commit it. If the API times out, errors, or returns an empty or invalid reply, dialogue falls back to the deterministic case rules with a clear in-game warning.

When an API key is configured, the game sends the latest question directly to Gemini or OpenAI along with the selected NPC's identity, personality, allowed knowledge, relevant evidence found by the player, and that NPC's own recent conversation. The model generates the dialogue rather than paraphrasing a prewritten answer. Local case rules still interpret gameplay topics, enforce trust and evidence gates, award clues, and control progress; model output cannot award clues, change game state, or choose the culprit. If dialogue generation fails, the game uses the authored case reply and displays a warning. Without an API key, the full game remains playable with authored replies.

## How to play

1. Sign in with any investigator codename. There are no accounts or passwords; the codename is saved in this browser. Refreshing starts the case again from its opening briefing.
2. Walk around the scene with **W/A/S/D** or the **arrow keys**. Click the room first if the keys do not move the investigator. Press **E** near a person or clue to interact. Clicking a clue or the talk marker also walks the investigator over before interacting. The person in the interview scene moves between nearby spots while waiting; the game shows the currently selected person in that shared scene.
3. Select a person from the left rail, then ask a question with the text box or suggested prompts. Tap the microphone, choose **Allow** when the browser asks, speak clearly, pause, review the transcript, and press the send arrow. Voice recognition requires a supported browser speech service (Chrome/Edge generally work best), microphone permission, and an internet connection. In an embedded browser, use the address-bar site controls to allow the mic or open the local game in Chrome/Edge. If the service is unavailable, the status beneath the input says why; typing remains available.
4. NPC replies can be spoken aloud by your browser. Use **VOICE ON/OFF** and the volume slider beside the speaker's name to control this. Voice availability and the voices that sound best depend on the browser and operating system. This speech output is separate from microphone input; the game does not read your typed or spoken questions aloud.
5. Ask respectful, specific questions to earn trust. Accusations and threats lower it. Trust is bounded from 0 to 100, affects Sarah's willingness to testify and Alex's camera disclosure, and is saved with the case.
6. Inspect the highlighted objects in each room. The **Server Floor** unlocks after the badge record; **Records Archive** unlocks after the camera record and Sarah's testimony. Use the location tabs to walk through the exit into an unlocked area.
7. Open **Evidence** to compare verified records, NPC claims, and your scene observations. NPCs remember which clues you showed them, so cite records in a later interview to challenge a claim.
8. When ready, choose **Make your accusation**, select a suspect, check the evidence that supports your theory, and explain how it fits. An early accusation can be insufficient; a correct but weak case differs from a supported solved case.

The opening field briefing explains the controls. The restart control and ordinary page refresh both begin a fresh copy of the current case from the opening scene.

## Learning systems

- A categorical Naive Bayes classifier predicts the player's next investigation action from case stage, observed action style, interview trust, location, NPC, and evidence count. It is trained on 3,200 simulated gameplay episodes, split by episode into train and held-out sets, and evaluated against a most-frequent-action baseline. Its learned counts and test metrics are saved in `models/insider_learning.json`.
- A tabular Q-learning suspect-strategy agent learns among valid dialogue tactics (de-escalate, request corroboration, offer a safe fact, or hold a boundary). Its state includes observed player style, case stage, trust band, and tone. It trains for 18,000 simulated episodes; the Q table and reward checkpoints are saved. In actual interviews, it can select a procedural tactic and update that NPC's per-session strategy values from trust and question outcomes. Those values are saved with the case. It never supplies case facts or awards evidence.
- The **AI LAB** button displays held-out prediction accuracy, baseline accuracy, Q-learning reward progress and evaluation versus a fixed-policy baseline, plus real runtime inference and completed-case counts. Live accuracy appears only after a later player action can score a prior prediction.
- During interviews, **Behavioral Read** gives a transparent heuristic about the suspect's likely next response and a suggested follow-up, using the current in-game attitude, trust, dialogue tone, and evidence already shown. This is a game-state simulation, not automatic webcam posture recognition; it does not claim to read a real person's thoughts.
- After a non-insufficient case ending, **Counterfactual Replay** evaluates a different suspect/evidence/theory combination with the exact same accusation rules on a deep copy. The real case state is never changed.

The supervised model, Q-learning policy, optional LLM intent/reply helpers, and authoritative case rules have separate jobs. The local ML training and inference use Python's standard library. An OpenAI key is optional; evidence and endings remain deterministic.

To reproduce training and replace the saved model artifact, run `python train_models.py` from this folder. The deterministic seed makes the simulation repeatable.

## The case rules

The underlying facts do not change: Ravi entered the server corridor at 10:42 PM; the file was opened at 10:47 PM; the camera feed looped at 10:39 PM under an override from Mark's office. Ravi copied the file to preserve proof of Mark's planned data sale, then panicked and deleted a later audit row. Ravi copied the file; Mark planned the sale. Sarah saw Ravi with a small metal USB but initially withheld her testimony. Alex can verify badge and camera records but does not know the file's contents or Ravi's motive. Mark cannot tell the player Ravi's private reason.

Evidence has IDs, sources, reveal conditions, and prerequisites in `main.py`. The server is authoritative for evidence, dialogue outcomes, movement, trust, and endings. A model can classify intent but cannot change the truth or award a clue. A JSON file with atomic replacement persists bounded per-NPC memory and session state.

## Progression rules

| Action | Requirement / result |
| --- | --- |
| Badge record | Ask Alex about badge access; adds the 10:42 record and unlocks Server Floor. |
| Camera loop | Ask Alex respectfully or build trust to 52; reveals the 10:39 override. |
| Sarah's testimony | Ask about her observation with trust at least 52 and without hostility, or show her the badge record. A refusal never adds evidence. |
| Deleted audit row | On Server Floor, inspect the terminal after obtaining the badge record. |
| Approval ledger | Unlock Records Archive after collecting both the camera record and witness statement; inspect its ledger. |
| Ravi's motive | Present both badge record and Sarah's witness statement to Ravi. Only Ravi can confirm his private reason. |
| Accusation | Needs badge record plus witness for a minimally defensible case. A well-supported solved ending additionally needs the relevant motive confirmation and citations. |

## Unlocked follow-up case

Solving Case 047 with a supported accusation unlocks **Case 048: The Missing Minutes**, a separate investigation about a boardroom recording erased before an employee complaint review. It has its own evidence IDs, clue gates, witness and suspect responses, room objectives, state persistence, and ending evaluation. The conclusion identifies who ordered the erasure and distinguishes that act from Ravi preserving a backup. Restarting replays the current chapter; the Case 048 button appears only after the Case 047 solved ending.

## How the game demonstrates the hackathon stages

**Stage 1 — Conversational dialogue:** players type free-form questions. Structured intent classification (optional OpenAI) interprets meaning; offline synonym/phrase rules keep the demo playable. Ambiguous questions receive clarification. Answers are selected from deterministic, NPC-specific knowledge and evidence rules.

**Stage 2 — Conversation drives gameplay:** dialogue changes trust, reveals or withholds evidence, unlocks locations, updates objectives, and gates the ending. Scene objects only work in the correct unlocked location. The accusation UI sends selected evidence IDs and the player's optional theory to the backend, where both are evaluated.

**Stage 3 — Cognitive NPC behavior:** each character has bounded persistent memory of questions, answers, presented/seen evidence, trust causes, topics, threats, accusations, contradictions, revelations, and current attitude. Ravi recognizes records shown to him; Sarah's caution and Alex's nervousness change disclosure; Mark deflects and reacts defensively to a camera record. NPC knowledge boundaries prevent them from speaking for each other.

## Test

Install dependencies as above. Run the full API and game-rule suite with:

```powershell
python -m pytest -q tests
```

A dependency-light rule suite is also included and runs with Python itself:

```powershell
python -m unittest discover -s tests -p "test_engine_unittest.py" -v
```

## Files

- `main.py` — FastAPI routes, structured intent/fallback, canonical facts, evidence gates, persistence, NPC memory, progression, and accusation evaluation.
- `learning.py` and `models/insider_learning.json` — simulated training, held-out supervised evaluation, Q-learning policy, learned policy artifact, and live metrics.
- `static/index.html`, `static/style.css`, `static/app.js`, `static/controls.js` — local investigator sign-in, walkable 2D rooms, keyboard controls, speech-recognition feedback, interactive hotspots, dialogue, evidence, tutorial, and accusation UI.
- `tests/test_game.py` — pytest API and game-rule test cases.
- `tests/test_engine_unittest.py` — offline standard-library game-rule tests.
- `DEMO_SCRIPT.md` — exact live-demo inputs, expected behavior, state changes, and alternate route.
- `IMPLEMENTATION_CHECKLIST.md` — prompt audit, completion checklist, verification results, and the remaining integration limitations.
- `.env.example` — optional server-side model settings.

## Limits to disclose

This is a single-player, two-case local MVP. Offline intent recognition is deterministic and phrase-based, so sufficiently unusual paraphrases may need a clearer question. Case 048 uses deterministic intent rules; optional OpenAI structured classification is currently used by Case 047. The model does not generate freeform factual dialogue. State is local JSON without multi-user concurrency or accounts. The profile screen is a local save label, not authentication. Voice capture uses the browser's Web Speech API, so support depends on browser, microphone permission, and network access. The visual game is a walkable stylized 2D scene in HTML/CSS, not a 3D engine. The full pytest API suite requires `pytest` and `httpx`; the standard-library rule suite can run without them.
